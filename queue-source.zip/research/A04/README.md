# A04 — Embla Carousel

Status: queued

Original: https://www.embla-carousel.com/docs/examples/predefined

Source: https://github.com/davidjerleke/embla-carousel

Pinned revision: 0423b61463dd6f095d7aca810a49bbf194d6c291

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Dragging, previous/next controls and pagination dots must identify the same slide.

Catalog paths: Components/Interactions

Acquisition: clone. Reuse policy: review-before-vendoring.

Effect role: none

Implementation: Pending; no reconstruction or imported assets supplied.
