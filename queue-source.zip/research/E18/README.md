# E18 — Variable font axes

Status: queued

Original: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/font-variation-settings

Source: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/font-variation-settings

Pinned revision: Not applicable

License evidence: Platform reference only; no documentation code copied; No upstream code bundled; original implementation planned

Acceptance: The title fits its container; without the variable font the complete text remains readable.

Catalog paths: Components/Effects/Text and numbers

Acquisition: study. Reuse policy: independent-implementation.

Effect role: element-attachment

Target: Heading or index with supported font axes

Trigger: hover, focus, viewport-enter

Parameters: axis, min, max, duration

Export: Embed only a font licensed for redistribution; include a system-font fallback.

Reduced motion: Use fixed width and weight.

Implementation: Pending; no reconstruction or imported assets supplied.
