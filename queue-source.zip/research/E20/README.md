# E20 — Frosted glass panel

Status: queued

Original: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/backdrop-filter

Source: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/backdrop-filter

Pinned revision: Not applicable

License evidence: Platform reference only; no documentation code copied; No upstream code bundled; original implementation planned

Acceptance: Text remains readable over light and dark backgrounds; unsupported blur has an opaque fallback.

Catalog paths: Components/Effects/Backgrounds and materials

Acquisition: study. Reuse policy: independent-implementation.

Effect role: element-attachment

Target: Navigation, overlay or HUD panel

Trigger: static, theme-change

Parameters: blur, baseOpacity, border

Export: Inline scoped backdrop-filter CSS with a sufficiently opaque contrast base.

Reduced motion: Keep blur fixed without animation.

Implementation: Pending; no reconstruction or imported assets supplied.
