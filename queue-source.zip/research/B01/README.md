# B01 — daisyUI Button

Status: queued

Original: https://daisyui.com/components/button/

Source: https://github.com/saadeghi/daisyui

Pinned revision: bf3bac3a397b543e55641ecb2d60a2ed961f09ec

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Compare solid, outline, ghost, icon, sizes and disabled states in one page.

Implementation: Pending; no reconstruction or imported assets supplied.
