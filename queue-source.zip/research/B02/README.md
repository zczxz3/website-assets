# B02 — Bootstrap Buttons

Status: queued

Original: https://getbootstrap.com/docs/5.3/components/buttons/

Source: https://github.com/twbs/bootstrap

Pinned revision: 3b7f32318876bbd3c9cc14d3f891d744f39cd538

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Check native disabled behavior and aria-pressed with keyboard activation.

Implementation: Pending; no reconstruction or imported assets supplied.
