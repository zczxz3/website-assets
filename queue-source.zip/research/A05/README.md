# A05 — SortableJS

Status: implemented-bounded-study

Original: https://sortablejs.github.io/Sortable/

Source: https://github.com/SortableJS/Sortable

Pinned revision: 48b626bbc61afbb0f179730c1dd3cca3dcc8b788

License evidence: Pinned LICENSE read; MIT

Acceptance: Reorder items, add from a shelf, synchronize preview and export; provide keyboard and touch controls.

Implementation: See QUEUE_RESEARCH.md and queue-components.mjs / queue-model.mjs.
