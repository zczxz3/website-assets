# E02 — Mask reveal

Status: queued

Original: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/clip-path

Source: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/clip-path

Pinned revision: Not applicable

License evidence: Platform reference only; no documentation code copied; No upstream code bundled; original implementation planned

Acceptance: A circle from the selected origin or a directional rectangle reveals all corners after an image change.

Catalog paths: Components/Effects/Entrance and reveal

Acquisition: study. Reuse policy: independent-implementation.

Effect role: element-attachment

Target: Image, cover or title container

Trigger: viewport-enter, click

Parameters: shape, origin, direction, duration

Export: Inline clip-path keyframes and a trigger; remove clipping in the unsupported fallback.

Reduced motion: Show the complete target immediately.

Implementation: Pending; no reconstruction or imported assets supplied.
