# B09 — Pretty Checkbox

Status: implemented-bounded-study

Original: https://lokesh-coder.github.io/pretty-checkbox/

Source: https://github.com/lokesh-coder/pretty-checkbox

Pinned revision: 84ef0d820146ccfaa181649f45dff71a7026ca21

License evidence: Pinned LICENSE read; MIT

Acceptance: Keep checkbox, radio and switch inputs operable with Tab, Space and touch, with visible focus.

Catalog paths: Components/Basic controls

Acquisition: clone. Reuse policy: review-before-vendoring.

Effect role: none

Implementation: See QUEUE_RESEARCH.md and queue-components.mjs / queue-model.mjs.
