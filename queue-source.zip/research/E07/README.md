# E07 — Card tilt and glare

Status: queued

Original: https://micku7zu.github.io/vanilla-tilt.js/

Source: https://github.com/micku7zu/vanilla-tilt.js

Pinned revision: 48f4ee931d4d91dcdd2f91803db67a9f3a16587e

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Reset on pointer leave, preserve touch clicks and recompute bounds after editor movement.

Catalog paths: Components/Effects/Pointer and feedback

Acquisition: clone. Reuse policy: review-before-vendoring.

Effect role: element-attachment

Target: Card, cover or button inner wrapper

Trigger: fine-pointer-move

Parameters: maxAngle, perspective, glare, resetDuration

Export: Keep editor placement on an outer wrapper and tilt transforms on an inner effect layer.

Reduced motion: Keep the card static.

Implementation: Pending; no reconstruction or imported assets supplied.
