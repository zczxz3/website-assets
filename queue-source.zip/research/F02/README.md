# F02 — HTML5 UP Dimension

Status: queued

Original: https://html5up.net/uploads/demos/dimension/

Source: https://html5up.net/dimension

Pinned revision: Not applicable

License evidence: Official license page read; CC-BY-3.0 (template attribution required; assets separate)

Acceptance: Open a panel, close or navigate back, and verify mobile; preserve HTML5 UP attribution and audit asset credits.

Catalog paths: Websites/References and templates

Acquisition: download. Reuse policy: review-before-vendoring.

Effect role: none

Implementation: Pending; no reconstruction or imported assets supplied.
