# E06 — Number counter

Status: queued

Original: https://inorganik.github.io/countUp.js/

Source: https://github.com/inorganik/countUp.js

Pinned revision: a47732056085af3e0e81374db71e088dddf17362

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Handle negative numbers, decimals and units; finish at the exact formatted destination value.

Catalog paths: Components/Effects/Text and numbers

Acquisition: clone. Reuse policy: review-before-vendoring.

Effect role: element-attachment

Target: Metric, card number or index

Trigger: viewport-enter, value-change

Parameters: start, end, precision, duration, prefix, suffix

Export: Bundle the chosen counter or original formatter; initial HTML contains the readable final value.

Reduced motion: Set the final formatted number immediately.

Implementation: Pending; no reconstruction or imported assets supplied.
