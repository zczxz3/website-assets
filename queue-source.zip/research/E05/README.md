# E05 — Typewriter and erase

Status: queued

Original: https://mattboldt.com/demos/typed-js/

Source: https://github.com/mattboldt/typed.js

Pinned revision: b2d6a7d9af6d9cd39830701f6b6a7cd98a37e13f

License evidence: Pinned upstream README licensing section reviewed; v3 is not MIT. No upstream runtime bundled.; GPL-3.0 or commercial license

Acceptance: Preserve Chinese and emoji graphemes, reserve layout space and allow looping to stop.

Catalog paths: Components/Effects/Text and numbers

Acquisition: study. Reuse policy: independent-implementation; upstream runtime excluded.

Effect role: element-attachment

Target: Heading, short phrase or tutorial

Trigger: load, click-play

Parameters: typeSpeed, pause, eraseSpeed, loop

Export: Write original plain JavaScript; do not bundle current Typed.js code in the permissive component pack.

Reduced motion: Show the complete text without a blinking cursor.

Implementation: Pending; no reconstruction or imported assets supplied.
