# E09 — Success confetti

Status: queued

Original: https://www.kirilv.com/canvas-confetti/

Source: https://github.com/catdad/canvas-confetti

Pinned revision: 20eebad51dde793070c373d594099a7ed8d96e22

License evidence: GitHub metadata only; per-file review pending; ISC

Acceptance: A real success event fires once; an ordinary click must not manufacture business success; rendering stops after completion.

Catalog paths: Components/Effects/Pointer and feedback

Acquisition: clone. Reuse policy: review-before-vendoring.

Effect role: block-layer

Target: Completion area or button feedback layer

Trigger: success-event, explicit-preview

Parameters: count, angle, colors, origin

Export: Bundle a one-shot renderer; keep independent readable success text.

Reduced motion: Skip particles and retain the status text.

Implementation: Pending; no reconstruction or imported assets supplied.
