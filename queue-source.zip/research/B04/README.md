# B04 — Carbon Button

Status: queued

Original: https://www.carbondesignsystem.com/building-blocks/core/components/button/guidelines

Source: https://github.com/carbon-design-system/carbon

Pinned revision: 2efc91b00c814e390bfa431f0f5555f3028e7100

License evidence: GitHub metadata only; per-file review pending; Apache-2.0

Acceptance: Group Save, Cancel and Delete with explicit labels and danger semantics.

Implementation: Pending; no reconstruction or imported assets supplied.
