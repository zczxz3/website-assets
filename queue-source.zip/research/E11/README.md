# E11 — Image parallax

Status: queued

Original: https://simpleparallax.com/

Source: https://github.com/geosigno/simpleParallax.js

Pinned revision: 55f4d10f6f0b4e1ec50041f9a2266b82bf6ee129

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Scrolling forward and backward is reversible; narrow layouts expose no empty edges; pause offscreen.

Catalog paths: Components/Effects/Scroll and transitions

Acquisition: clone. Reuse policy: review-before-vendoring.

Effect role: element-attachment

Target: Image or cover inside a clipping wrapper

Trigger: scroll

Parameters: direction, scale, amplitude, scrollContainer

Export: Export self-owned images, a crop wrapper and a native JavaScript entry point.

Reduced motion: Render a static cover image.

Implementation: Pending; no reconstruction or imported assets supplied.
