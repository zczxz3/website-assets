# F07 — Vercel Shop

Status: queued

Original: https://template.vercel.shop/

Source: https://github.com/vercel/shop

Pinned revision: 55a2cc341d0add38dcaa8ee64d83c19e001d8c14

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Connect product list, detail, variants and cart with mock data; identify Shopify service and checkout boundaries.

Implementation: Pending; no reconstruction or imported assets supplied.
