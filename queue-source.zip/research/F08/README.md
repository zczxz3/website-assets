# F08 — Excalidraw

Status: queued

Original: https://excalidraw.com/

Source: https://github.com/excalidraw/excalidraw

Pinned revision: dd2f8fc32b92cbf56f4abee6a0cf3b14681b4b55

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Select a tool, draw, select/edit, undo/redo and export in a local single-user scope.

Catalog paths: Websites/Applications

Acquisition: clone. Reuse policy: review-before-vendoring.

Effect role: none

Implementation: Pending; no reconstruction or imported assets supplied.
