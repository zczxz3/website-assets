# B07 — Hamburgers

Status: implemented-bounded-study

Original: https://jonsuh.com/hamburgers/

Source: https://github.com/jonsuh/hamburgers

Pinned revision: b26b25f8c70d1412a73a0bf046c980710843dfca

License evidence: Pinned LICENSE read; MIT

Acceptance: Compare spin, spring and collapse; keep a real panel and aria-expanded synchronized; Escape returns focus.

Implementation: See QUEUE_RESEARCH.md and queue-components.mjs / queue-model.mjs.
