# A02 — Headless UI Combobox

Status: queued

Original: https://headlessui.com/react/combobox

Source: https://github.com/tailwindlabs/headlessui

Pinned revision: eea57cf46fd6767ed1059012f7073b88eb159fba

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Filter items, move with arrow keys, select with Enter, and expose a no-results state.

Implementation: Pending; no reconstruction or imported assets supplied.
