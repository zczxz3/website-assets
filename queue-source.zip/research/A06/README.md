# A06 — Anime.js Timeline

Status: queued

Original: https://animejs.com/documentation/timeline/

Source: https://github.com/juliangarnier/anime

Pinned revision: 01b81be1df6843ccfe0a71c0699a746bf740dd77

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Sequence mask, image and text with configurable overlaps; pause and replay deterministically.

Implementation: Pending; no reconstruction or imported assets supplied.
