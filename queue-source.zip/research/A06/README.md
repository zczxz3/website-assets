# A06 — Anime.js Timeline

Status: queued

Original: https://animejs.com/documentation/timeline/

Source: https://github.com/juliangarnier/anime

Pinned revision: 01b81be1df6843ccfe0a71c0699a746bf740dd77

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Sequence mask, image and text with configurable overlaps; pause and replay deterministically.

Catalog paths: Tools/Effect timeline

Acquisition: clone. Reuse policy: review-before-vendoring.

Effect role: orchestration-tool

Target: Mounted effects

Trigger: play, pause, replay

Parameters: offset, delay, easing

Export: Bundle the chosen engine with its license; serialize a timeline recipe.

Reduced motion: Set the final state.

Implementation: Pending; no reconstruction or imported assets supplied.
