# F04 — Fuwari

Status: queued

Original: https://fuwari.vercel.app/

Source: https://github.com/saicaca/fuwari

Pinned revision: 6d39b0dec41282e7852e23e032998a5789abee28

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Add a post and check home, archive, article and theme switching; illustration permissions are separate.

Catalog paths: Websites/References and templates

Acquisition: clone. Reuse policy: review-before-vendoring.

Effect role: none

Implementation: Pending; no reconstruction or imported assets supplied.
