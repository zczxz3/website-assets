# E08 — Cursor trail

Status: queued

Original: https://tholman.com/cursor-effects/

Source: https://github.com/tholman/cursor-effects

Pinned revision: 182a33839ad3ef63b14ad296e18bc1bb24a45bd6

License evidence: GitHub metadata only; per-file review pending; Unverified

Acceptance: Stay inside the selected block; removing the block removes its listeners and canvases.

Catalog paths: Components/Effects/Pointer and feedback

Acquisition: clone. Reuse policy: review-before-vendoring.

Effect role: block-layer

Target: Creative cover or bounded canvas section

Trigger: pointer-move

Parameters: style, color, scope

Export: Use a block-scoped pointer-events:none canvas and an explicit destroy lifecycle.

Reduced motion: Keep the system cursor with no trail.

Implementation: Pending; no reconstruction or imported assets supplied.
