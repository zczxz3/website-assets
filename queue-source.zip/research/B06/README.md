# B06 — 98.css

Status: queued

Original: https://jdan.github.io/98.css/

Source: https://github.com/jdan/98.css

Pinned revision: b1d7a907371bbe523d6f64e3af97f714fdbd6d6a

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Compare pressed edge shading and a separately visible keyboard focus outline.

Catalog paths: Components/Basic controls

Acquisition: clone. Reuse policy: review-before-vendoring.

Effect role: none

Implementation: Pending; no reconstruction or imported assets supplied.
