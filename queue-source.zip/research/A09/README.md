# A09 — React Bits Iridescence

Status: reference-only

Original: https://reactbits.dev/backgrounds/iridescence

Source: https://github.com/DavidHDev/react-bits

Pinned revision: 4dc7b5b7772e1217c8fb8d2a7aa074302180e5b4

License evidence: Official license page read; MIT + Commons Clause (component redistribution restricted)

Acceptance: Record public behavior only; do not package React Bits components or ports in the redistributable library.

Catalog paths: Components/Effects/Backgrounds and materials

Acquisition: study. Reuse policy: reference-only.

Effect role: block-layer

Target: Section background

Trigger: pointer-move, visible-loop

Parameters: color, speed, pointerResponse

Export: Reference only; exports require an original implementation or suitable permission.

Reduced motion: Use a static gradient.

Implementation: Pending; no reconstruction or imported assets supplied.
