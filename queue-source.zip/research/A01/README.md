# A01 — Radix Dialog

Status: queued

Original: https://www.radix-ui.com/primitives/docs/components/dialog

Source: https://github.com/radix-ui/primitives

Pinned revision: eb3a2b7091293e27df8f9ba906632d8daa3d81a3

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Open a dialog; cycle Tab within it; Escape closes; focus returns to its trigger.

Implementation: Pending; no reconstruction or imported assets supplied.
