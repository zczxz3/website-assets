# F06 — Tabler

Status: queued

Original: https://preview.tabler.io/

Source: https://github.com/tabler/tabler

Pinned revision: 096491dea4886f78891c2e29310351d5aee6c460

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Connect overview, list and form; audit every dependency including charts separately.

Implementation: Pending; no reconstruction or imported assets supplied.
