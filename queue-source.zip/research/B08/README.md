# B08 — Ladda

Status: implemented-bounded-study

Original: https://lab.hakim.se/ladda/

Source: https://github.com/hakimel/Ladda

Pinned revision: c7a9c44c5e9d6e200bc74771c6570e9bcff46063

License evidence: Pinned LICENSE read; MIT

Acceptance: Run one request at a time; retain button size; announce success, failure and cancellation; retry after failure.

Catalog paths: Components/Basic controls; Components/Effects/Pointer and feedback

Acquisition: clone. Reuse policy: review-before-vendoring.

Effect role: element-attachment

Target: Submit button

Trigger: async-state

Parameters: indicatorPosition, style, progress

Export: Export the original abortable task binding and readable status text.

Reduced motion: Use a static waiting indicator and readable progress.

Implementation: See QUEUE_RESEARCH.md and queue-components.mjs / queue-model.mjs.
