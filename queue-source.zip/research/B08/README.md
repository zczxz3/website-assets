# B08 — Ladda

Status: implemented-bounded-study

Original: https://lab.hakim.se/ladda/

Source: https://github.com/hakimel/Ladda

Pinned revision: c7a9c44c5e9d6e200bc74771c6570e9bcff46063

License evidence: Pinned LICENSE read; MIT

Acceptance: Run one request at a time; retain button size; announce success, failure and cancellation; retry after failure.

Implementation: See QUEUE_RESEARCH.md and queue-components.mjs / queue-model.mjs.
