# E01 — Fade and rise

Status: queued

Original: https://michalsnik.github.io/aos/

Source: https://github.com/michalsnik/aos

Pinned revision: 329fb34f777034345f4d3f4def4dc3bcc300cc2e

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Reveal on entry; once=true must not replay after leaving and re-entering.

Catalog paths: Components/Effects/Entrance and reveal

Acquisition: clone. Reuse policy: review-before-vendoring.

Effect role: element-attachment

Target: Heading, image or card

Trigger: viewport-enter

Parameters: distance, duration, delay, once

Export: Inline scoped transform/opacity CSS and an observer; content starts readable if JS fails.

Reduced motion: Show final position and full opacity.

Implementation: Pending; no reconstruction or imported assets supplied.
