# F03 — Magic UI Portfolio

Status: implemented-bounded-study

Original: https://portfolio-magicui.vercel.app/

Source: https://github.com/magicuidesign/portfolio

Pinned revision: 5ef12e4c8bd0de3e22e89c2181ee77a35925ec8b

License evidence: Pinned LICENSE read; MIT

Acceptance: Change owner, projects, cover colors, social URL and article; verify home, work detail, Dock, journal and offline export.

Catalog paths: Websites/References and templates

Acquisition: clone. Reuse policy: review-before-vendoring.

Effect role: none

Implementation: See QUEUE_RESEARCH.md and queue-components.mjs / queue-model.mjs.
