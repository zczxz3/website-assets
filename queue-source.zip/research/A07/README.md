# A07 — shadcn/ui Blocks

Status: queued

Original: https://ui.shadcn.com/blocks

Source: https://github.com/shadcn-ui/ui

Pinned revision: 4aaea19d9cff3e0908e12a8c1d504b8c5ec34610

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Collapse desktop navigation and open mobile navigation without breaking content width.

Implementation: Pending; no reconstruction or imported assets supplied.
