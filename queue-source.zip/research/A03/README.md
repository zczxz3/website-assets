# A03 — Floating UI Tooltip

Status: queued

Original: https://floating-ui.com/docs/tooltip

Source: https://github.com/floating-ui/floating-ui

Pinned revision: 93ea014e0344ec0169e9a03db8aee70e90fd5a09

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Trigger with hover and focus; move the target to viewport edges and verify placement flips.

Implementation: Pending; no reconstruction or imported assets supplied.
