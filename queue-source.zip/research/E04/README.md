# E04 — Character and word stagger

Status: queued

Original: https://splitting.js.org/guide.html

Source: https://github.com/shshaw/Splitting

Pinned revision: d5a8fd0137e90770ae10d2e0e874a4a101161544

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Chinese and English reveal in reading order; assistive technology receives the complete sentence; split only once.

Catalog paths: Components/Effects/Text and numbers

Acquisition: clone. Reuse policy: review-before-vendoring.

Effect role: element-attachment

Target: Heading or short text

Trigger: viewport-enter

Parameters: splitMode, stagger, distance, duration

Export: Inline original splitting logic and indexed CSS; preserve a whole accessible text alternative.

Reduced motion: Show the complete sentence immediately.

Implementation: Pending; no reconstruction or imported assets supplied.
