# E14 — Paper and film grain

Status: queued

Original: https://developer.mozilla.org/en-US/docs/Web/SVG/Reference/Element/feTurbulence

Source: https://developer.mozilla.org/en-US/docs/Web/SVG/Reference/Element/feTurbulence

Pinned revision: Not applicable

License evidence: Platform reference only; no documentation code copied; No upstream code bundled; original implementation planned

Acceptance: Two instances have independent filter IDs; texture does not intercept clicks.

Catalog paths: Components/Effects/Backgrounds and materials

Acquisition: study. Reuse policy: independent-implementation.

Effect role: block-layer

Target: Cover, background or image overlay

Trigger: static

Parameters: scale, opacity, seed

Export: Inline an original SVG feTurbulence filter with a unique ID per instance.

Reduced motion: Keep the texture static; never animate the seed.

Implementation: Pending; no reconstruction or imported assets supplied.
