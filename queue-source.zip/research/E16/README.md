# E16 — SVG stroke drawing

Status: queued

Original: https://animejs.com/documentation/svg/createdrawable/

Source: https://github.com/juliangarnier/anime

Pinned revision: 01b81be1df6843ccfe0a71c0699a746bf740dd77

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Paths of different lengths complete correctly and remain fully visible.

Catalog paths: Components/Effects/Vector graphics

Acquisition: clone. Reuse policy: review-before-vendoring.

Effect role: element-attachment

Target: Logo, map line or icon path

Trigger: load, viewport-enter, click

Parameters: order, direction, stagger, duration

Export: Use original getTotalLength/dash animation or a licensed minimal engine with self-owned SVG paths.

Reduced motion: Display complete paths.

Implementation: Pending; no reconstruction or imported assets supplied.
