# F09 — Webamp

Status: queued

Original: https://webamp.org/

Source: https://github.com/captbaritone/webamp

Pinned revision: 444ea5bb88e7eb8ef9a826f1e42f69b22674c337

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Import owned audio; synchronize play, seek, volume, playlist and windows; exclude bundled music or unreviewed skins.

Catalog paths: Websites/Applications

Acquisition: clone. Reuse policy: review-before-vendoring.

Effect role: none

Implementation: Pending; no reconstruction or imported assets supplied.
