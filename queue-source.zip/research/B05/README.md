# B05 — NES.css

Status: queued

Original: https://nostalgic-css.github.io/NES.css/

Source: https://github.com/nostalgic-css/NES.css

Pinned revision: b1cc9944aae3274461c747d7ad1cab31df45e78c

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Rebuild stepped corners and press depth with original CSS; test associated checkboxes.

Catalog paths: Components/Basic controls

Acquisition: clone. Reuse policy: review-before-vendoring.

Effect role: none

Implementation: Pending; no reconstruction or imported assets supplied.
