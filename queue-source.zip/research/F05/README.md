# F05 — Starlight

Status: queued

Original: https://starlight.astro.build/

Source: https://github.com/withastro/starlight

Pinned revision: 5a1997d5bddafb39ab00b6edd94781180016973c

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Verify side navigation, full-text search, page outline and mobile navigation on an authored documentation set.

Catalog paths: Websites/References and templates

Acquisition: clone. Reuse policy: review-before-vendoring.

Effect role: none

Implementation: Pending; no reconstruction or imported assets supplied.
