# B03 — Magic UI Shimmer Button

Status: queued

Original: https://magicui.design/docs/components/shimmer-button

Source: https://github.com/magicuidesign/magicui

Pinned revision: 166367b4e31a27f166fd6c2b71d7be290fe0c1bc

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Expose highlight width, period, radius and color; freeze motion under reduced motion.

Catalog paths: Components/Basic controls; Components/Effects/Pointer and feedback

Acquisition: clone. Reuse policy: review-before-vendoring.

Effect role: element-attachment

Target: Button or CTA

Trigger: visible-loop

Parameters: color, radius, period

Export: Preserve licensed source and inline scoped styles.

Reduced motion: Keep a static highlighted border.

Implementation: Pending; no reconstruction or imported assets supplied.
