# B03 — Magic UI Shimmer Button

Status: queued

Original: https://magicui.design/docs/components/shimmer-button

Source: https://github.com/magicuidesign/magicui

Pinned revision: 166367b4e31a27f166fd6c2b71d7be290fe0c1bc

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Expose highlight width, period, radius and color; freeze motion under reduced motion.

Implementation: Pending; no reconstruction or imported assets supplied.
