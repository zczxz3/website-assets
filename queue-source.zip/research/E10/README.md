# E10 — Reading progress

Status: queued

Original: https://scroll-driven-animations.style/demos/progress-bar/css/

Source: https://scroll-driven-animations.style/

Pinned revision: Not applicable

License evidence: Platform reference only; no documentation code copied; No upstream code bundled; original implementation planned

Acceptance: Main article top is 0% and bottom is 100%; scrolling an independent sidebar must not change article progress.

Catalog paths: Components/Effects/Scroll and transitions

Acquisition: study. Reuse policy: independent-implementation.

Effect role: element-attachment

Target: Article progress bar or sidebar indicator

Trigger: container-scroll

Parameters: orientation, color, thickness, scrollContainer

Export: Use a scoped scroll timeline with a JS fallback when needed; bind the actual scroll container.

Reduced motion: Synchronize progress without additional smoothing.

Implementation: Pending; no reconstruction or imported assets supplied.
