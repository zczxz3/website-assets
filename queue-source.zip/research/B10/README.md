# B10 — SpinKit

Status: implemented-bounded-study

Original: https://tobiasahlin.com/spinkit/

Source: https://github.com/tobiasahlin/SpinKit

Pinned revision: 742a71277c49b69053b5beb9fad80d720840a2ab

License evidence: Pinned LICENSE read; MIT

Acceptance: Show dots and wave with shared stagger parameters; preserve label width and a static reduced-motion state.

Implementation: See QUEUE_RESEARCH.md and queue-components.mjs / queue-model.mjs.
