# B10 — SpinKit

Status: implemented-bounded-study

Original: https://tobiasahlin.com/spinkit/

Source: https://github.com/tobiasahlin/SpinKit

Pinned revision: 742a71277c49b69053b5beb9fad80d720840a2ab

License evidence: Pinned LICENSE read; MIT

Acceptance: Show dots and wave with shared stagger parameters; preserve label width and a static reduced-motion state.

Catalog paths: Components/Basic controls; Components/Effects/Pointer and feedback

Acquisition: clone. Reuse policy: review-before-vendoring.

Effect role: element-attachment

Target: Button or loading area

Trigger: loading-state

Parameters: count, color, period

Export: Export scoped original keyframes and a separate readable status.

Reduced motion: Show a static waiting indicator.

Implementation: See QUEUE_RESEARCH.md and queue-components.mjs / queue-model.mjs.
