# E15 — Ink edge

Status: queued

Original: https://developer.mozilla.org/en-US/docs/Web/SVG/Reference/Element/feDisplacementMap

Source: https://developer.mozilla.org/en-US/docs/Web/SVG/Reference/Element/feDisplacementMap

Pinned revision: Not applicable

License evidence: Platform reference only; no documentation code copied; No upstream code bundled; original implementation planned

Acceptance: Distort shape edges only; body text remains clear and expanded filter bounds prevent clipping.

Catalog paths: Components/Effects/Backgrounds and materials

Acquisition: study. Reuse policy: independent-implementation.

Effect role: block-layer

Target: Self-owned SVG shape or chapter illustration

Trigger: viewport-enter, static

Parameters: frequency, displacement, seed, duration

Export: Compose original turbulence and displacement filters; keep text outside the filtered subtree.

Reduced motion: Use a static ink shape or the original undistorted shape.

Implementation: Pending; no reconstruction or imported assets supplied.
