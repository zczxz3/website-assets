# E19 — Linked particle background

Status: queued

Original: https://particles.js.org/demos/recipes/links

Source: https://github.com/tsparticles/tsparticles

Pinned revision: 19821ac564e3314ae3d188af2778597b8423693b

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Moving or removing a block leaves no extra canvases; reduce density on mobile.

Catalog paths: Components/Effects/Backgrounds and materials

Acquisition: clone. Reuse policy: review-before-vendoring.

Effect role: block-layer

Target: Banner or map-heading background

Trigger: visible-loop

Parameters: count, speed, linkDistance, color

Export: Bundle only the required engine and Links preset; impose a particle budget and static fallback.

Reduced motion: Use static points or a solid background.

Implementation: Pending; no reconstruction or imported assets supplied.
