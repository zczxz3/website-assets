# A08 — Codrops Scroll3DGrid

Status: queued

Original: https://tympanus.net/Development/Scroll3DGrid/

Source: https://github.com/codrops/Scroll3DGrid

Pinned revision: 69718a2eff87b32ab19764b3a6d7b3773dab6af3

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Use original images for one perspective layout; verify forward and reverse scrolling; review dependencies separately.

Implementation: Pending; no reconstruction or imported assets supplied.
