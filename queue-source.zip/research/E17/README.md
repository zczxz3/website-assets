# E17 — SVG contour morph

Status: queued

Original: https://animejs.com/documentation/svg/morphto/

Source: https://github.com/juliangarnier/anime

Pinned revision: 01b81be1df6843ccfe0a71c0699a746bf740dd77

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Rapid repeated toggles finish at the path matching the current application state.

Catalog paths: Components/Effects/Vector graphics

Acquisition: clone. Reuse policy: review-before-vendoring.

Effect role: state-transition

Target: Two compatible icon or illustration shapes

Trigger: click, state-change

Parameters: fromPath, toPath, duration, easing

Export: Export compatible self-owned paths and a chosen interpolator; cancel superseded transitions.

Reduced motion: Replace the path immediately.

Implementation: Pending; no reconstruction or imported assets supplied.
