# F01 — Start Bootstrap Agency

Status: queued

Original: https://startbootstrap.github.io/startbootstrap-agency/

Source: https://github.com/StartBootstrap/startbootstrap-agency

Pinned revision: b2d5d5c6b1396bc5b0e8dd92c693b106cfb7cee1

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Navigate to work, open and close a project, restore focus and check the mobile menu; contact delivery is separate.

Implementation: Pending; no reconstruction or imported assets supplied.
