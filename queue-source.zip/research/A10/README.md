# A10 — GSAP ScrollTrigger

Status: reference-only

Original: https://gsap.com/docs/v3/Plugins/ScrollTrigger/

Source: https://github.com/greensock/GSAP

Pinned revision: 5e6c35ff8eedea12d4f229129def635277d8b0f2

License evidence: Official license page read; GSAP Standard License (builder restrictions)

Acceptance: Keep license documentation only for this builder; no GSAP product reverse engineering for a competing visual animation builder.

Catalog paths: Tools/Scroll orchestration

Acquisition: study. Reuse policy: reference-only.

Effect role: orchestration-tool

Target: Story chapter

Trigger: scroll

Parameters: start, end, pin, scrub

Export: Reference only; do not distribute restricted runtime integration in Studio.

Reduced motion: Use natural document flow.

Implementation: Pending; no reconstruction or imported assets supplied.
