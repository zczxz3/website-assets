# E03 — Hand-drawn annotation

Status: queued

Original: https://roughnotation.com/

Source: https://github.com/rough-stuff/rough-notation

Pinned revision: 668ba82ac89c903d6f59c9351b9b85855da9882c

License evidence: GitHub metadata only; per-file review pending; MIT

Acceptance: Underline or circle remains aligned after wrapping; repeated entry creates no duplicate SVG nodes.

Catalog paths: Components/Effects/Text and numbers

Acquisition: clone. Reuse policy: review-before-vendoring.

Effect role: element-attachment

Target: Single-line or multiline text

Trigger: viewport-enter, click

Parameters: type, strokeWidth, color, duration

Export: Bundle the chosen licensed annotation runtime; measure after fonts load and on resize.

Reduced motion: Render the completed annotation.

Implementation: Pending; no reconstruction or imported assets supplied.
