# E12 — Shared-element transition

Status: queued

Original: https://developer.mozilla.org/en-US/docs/Web/API/Document/startViewTransition

Source: https://developer.mozilla.org/en-US/docs/Web/API/Document/startViewTransition

Pinned revision: Not applicable

License evidence: Platform reference only; no documentation code copied; No upstream code bundled; original implementation planned

Acceptance: Open the matching image and restore focus on return; navigation still works without the API.

Catalog paths: Components/Effects/Scroll and transitions

Acquisition: study. Reuse policy: independent-implementation.

Effect role: state-transition

Target: Thumbnail and corresponding detail hero

Trigger: open, back

Parameters: source, target, duration, easing

Export: Use unique view-transition names and a same-document state update; provide an immediate update fallback.

Reduced motion: Update state and restore focus immediately.

Implementation: Pending; no reconstruction or imported assets supplied.
