# E13 — Flowing mesh gradient

Status: queued

Original: https://shaders.paper.design/mesh-gradient

Source: https://github.com/paper-design/shaders

Pinned revision: 2fec1d57247033a7e72052156c65a826cff08ccb

License evidence: Apache-2.0 metadata and pinned NOTICE reviewed. Retain LICENSE and NOTICE when bundling; assets and dependencies still require review.; Apache-2.0

Acceptance: Pause offscreen; disabling WebGL leaves readable content and working controls.

Catalog paths: Components/Effects/Backgrounds and materials

Acquisition: clone. Reuse policy: review-before-vendoring.

Effect role: block-layer

Target: Hero, banner or empty-state background

Trigger: visible-loop

Parameters: colors, speed, distortion, swirl

Export: Bundle only the chosen native shader entry; retain Apache LICENSE and NOTICE; include a CSS gradient base.

Reduced motion: Use a static gradient with no rendering loop.

Implementation: Pending; no reconstruction or imported assets supplied.
