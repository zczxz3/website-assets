# Disclosure stack

Native details disclosure with Enter, Space and touch activation.

## Boundaries

Sections open independently; not an ARIA tabs widget.

## Edit

Text, --mf-accent, --mf-radius, --mf-space and --mf-duration.

## Interaction

Native controls work with keyboard/touch. Buttons provide focus, hover, press and release styling only; bind application actions separately. Reduced-motion rules disable animation. No state persistence or remote requests are implemented.

## Provenance

Independent implementation; no third-party source copied. Original code: MIT.

- [CodeHarem](https://codeharem.com/) — reference only, no source copied.
- [Pure CSS](https://purecss.com/) — reference only, no source copied.
- [CSSUI](https://www.cssui.dev/) — reference only, no source copied.
