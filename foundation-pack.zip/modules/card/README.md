# Editorial card

Responsive semantic article with an original CSS illustration.

## Boundaries

Illustration is procedural; replace the example link.

## Edit

Text, --mf-accent, --mf-radius, --mf-space and --mf-duration.

## Interaction

Native controls work with keyboard/touch. Buttons provide focus, hover, press and release styling only; bind application actions separately. Reduced-motion rules disable animation. No state persistence or remote requests are implemented.

## Provenance

Independent implementation; no third-party source copied. Original code: MIT.

- [Uiverse](https://uiverse.io/) — reference only, no source copied.
- [GEMILAN Code](https://gemilan.com/code) — reference only, no source copied.
- [CodeFronts](https://codefronts.com/) — reference only, no source copied.
- [Movin Components](https://movin.design/components/) — reference only, no source copied.
