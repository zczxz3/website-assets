# Text field

Native editable text with a persistent label and visible focus.

## Boundaries

No save or network submission.

## Edit

Text, --mf-accent, --mf-radius, --mf-space and --mf-duration.

## Interaction

Native controls work with keyboard/touch. Buttons provide focus, hover, press and release styling only; bind application actions separately. Reduced-motion rules disable animation. No state persistence or remote requests are implemented.

## Provenance

Independent implementation; no third-party source copied. Original code: MIT.

- [Uiverse](https://uiverse.io/) — reference only, no source copied.
- [CodeHarem](https://codeharem.com/) — reference only, no source copied.
- [Movin Components](https://movin.design/components/) — reference only, no source copied.
