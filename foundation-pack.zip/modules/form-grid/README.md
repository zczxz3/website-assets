# Responsive field group

Auto-fitting native fields for compact and wide containers.

## Boundaries

Fieldset only; no submission button or backend.

## Edit

Text, --mf-accent, --mf-radius, --mf-space and --mf-duration.

## Interaction

Native controls work with keyboard/touch. Buttons provide focus, hover, press and release styling only; bind application actions separately. Reduced-motion rules disable animation. No state persistence or remote requests are implemented.

## Provenance

Independent implementation; no third-party source copied. Original code: MIT.

- [CodeHarem](https://codeharem.com/) — reference only, no source copied.
- [WebDevSnippets](https://webdevsnippets.com/) — reference only, no source copied.
- [HyperUI](https://hyperui.dev/) — reference only, no source copied.
