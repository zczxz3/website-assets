# Loading indicator

One-element rotation with visible status text and reduced-motion support.

## Boundaries

Illustrative status, not connected to a request. Remove when loading completes.

## Edit

Text, --mf-accent, --mf-radius, --mf-space and --mf-duration.

## Interaction

Native controls work with keyboard/touch. Buttons provide focus, hover, press and release styling only; bind application actions separately. Reduced-motion rules disable animation. No state persistence or remote requests are implemented.

## Provenance

Independent implementation; no third-party source copied. Original code: MIT.

- [CSS Loaders](https://css-loaders.com/) — reference only, no source copied.
- [Loading.css](https://loading.io/animation/) — reference only, no source copied.
