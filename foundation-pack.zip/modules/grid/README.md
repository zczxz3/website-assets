# Responsive content grid

Auto-fit layout that responds to its container without JavaScript.

## Boundaries

No drag-and-drop logic inside the exported component.

## Edit

Text, --mf-accent, --mf-radius, --mf-space and --mf-duration.

## Interaction

Native controls work with keyboard/touch. Buttons provide focus, hover, press and release styling only; bind application actions separately. Reduced-motion rules disable animation. No state persistence or remote requests are implemented.

## Provenance

Independent implementation; no third-party source copied. Original code: MIT.

- [WebDevSnippets](https://webdevsnippets.com/) — reference only, no source copied.
- [HyperUI](https://hyperui.dev/) — reference only, no source copied.
- [Purely CSS](https://purelycss.com/) — reference only, no source copied.
