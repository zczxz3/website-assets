# Inline help disclosure

Persistent click-to-open help, usable without hover.

## Boundaries

Not a tooltip or modal; no focus trap is needed.

## Edit

Text, --mf-accent, --mf-radius, --mf-space and --mf-duration.

## Interaction

Native controls work with keyboard/touch. Buttons provide focus, hover, press and release styling only; bind application actions separately. Reduced-motion rules disable animation. No state persistence or remote requests are implemented.

## Provenance

Independent implementation; no third-party source copied. Original code: MIT.

- [AIMRAN Library](https://library.aimran.es/) — reference only, no source copied.
- [CSSUI](https://www.cssui.dev/) — reference only, no source copied.
