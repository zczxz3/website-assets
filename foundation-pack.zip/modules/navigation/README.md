# Compact navigation

Native disclosure navigation with real link destinations.

## Boundaries

Replace example.com links before publishing; not an ARIA application menu.

## Edit

Text, --mf-accent, --mf-radius, --mf-space and --mf-duration.

## Interaction

Native controls work with keyboard/touch. Buttons provide focus, hover, press and release styling only; bind application actions separately. Reduced-motion rules disable animation. No state persistence or remote requests are implemented.

## Provenance

Independent implementation; no third-party source copied. Original code: MIT.

- [WebDevSnippets](https://webdevsnippets.com/) — reference only, no source copied.
- [HyperUI](https://hyperui.dev/) — reference only, no source copied.
- [CSSUI](https://www.cssui.dev/) — reference only, no source copied.
