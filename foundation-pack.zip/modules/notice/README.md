# Information notice

Persistent informational message with a clear heading.

## Boundaries

Not an ephemeral toast; no dismiss control or live announcement.

## Edit

Text, --mf-accent, --mf-radius, --mf-space and --mf-duration.

## Interaction

Native controls work with keyboard/touch. Buttons provide focus, hover, press and release styling only; bind application actions separately. Reduced-motion rules disable animation. No state persistence or remote requests are implemented.

## Provenance

Independent implementation; no third-party source copied. Original code: MIT.

- [CodeHarem](https://codeharem.com/) — reference only, no source copied.
- [CodeShack Snippets](https://codeshack.io/snippets/) — reference only, no source copied.
- [Pure CSS](https://purecss.com/) — reference only, no source copied.
