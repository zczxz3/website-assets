# Plan card

Structured plan details and a real navigation link.

## Boundaries

Sample pricing only; does not start a purchase.

## Edit

Text, --mf-accent, --mf-radius, --mf-space and --mf-duration.

## Interaction

Native controls work with keyboard/touch. Buttons provide focus, hover, press and release styling only; bind application actions separately. Reduced-motion rules disable animation. No state persistence or remote requests are implemented.

## Provenance

Independent implementation; no third-party source copied. Original code: MIT.

- [HyperUI](https://hyperui.dev/) — reference only, no source copied.
- [Movin Components](https://movin.design/components/) — reference only, no source copied.
