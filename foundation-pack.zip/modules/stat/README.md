# Metric card

Responsive metric presentation with readable labels.

## Boundaries

Static example value, not live analytics.

## Edit

Text, --mf-accent, --mf-radius, --mf-space and --mf-duration.

## Interaction

Native controls work with keyboard/touch. Buttons provide focus, hover, press and release styling only; bind application actions separately. Reduced-motion rules disable animation. No state persistence or remote requests are implemented.

## Provenance

Independent implementation; no third-party source copied. Original code: MIT.

- [GEMILAN Code](https://gemilan.com/code) — reference only, no source copied.
- [WebDevSnippets](https://webdevsnippets.com/) — reference only, no source copied.
- [HyperUI](https://hyperui.dev/) — reference only, no source copied.
