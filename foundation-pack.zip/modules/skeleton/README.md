# Loading skeleton

Decorative shimmer paired with text rather than false content.

## Boundaries

Static loading example; no automatic completion.

## Edit

Text, --mf-accent, --mf-radius, --mf-space and --mf-duration.

## Interaction

Native controls work with keyboard/touch. Buttons provide focus, hover, press and release styling only; bind application actions separately. Reduced-motion rules disable animation. No state persistence or remote requests are implemented.

## Provenance

Independent implementation; no third-party source copied. Original code: MIT.

- [Animated UI Library](https://saurabhbhayana.com/ui-library) — reference only, no source copied.
- [CSS Loaders](https://css-loaders.com/) — reference only, no source copied.
- [Pure CSS](https://purecss.com/) — reference only, no source copied.
