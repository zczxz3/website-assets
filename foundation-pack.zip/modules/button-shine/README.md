# Light sweep

Light: original Button Atlas pattern adapted to static HTML/CSS, with focus and press feedback.

## Boundaries

Visual button only; bind application actions separately. For roll edit both copies; for stagger update visible letters and aria-label together.

## Edit

Text, --mf-accent, --mf-radius, --mf-space and --mf-duration.

## Interaction

Native controls work with keyboard/touch. Buttons provide focus, hover, press and release styling only; bind application actions separately. Reduced-motion rules disable animation. No state persistence or remote requests are implemented.

## Provenance

Independent implementation; no third-party source copied. Original code: MIT.

- [CSS Buttons](https://cssbuttons.io/) — reference only, no source copied.
- [Button Interaction Specs](https://github.com/jsabutis/button-interaction-specs) — reference only, no source copied.
