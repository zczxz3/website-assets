function changeMessage() {
  const message = document.getElementById("message");
  message.textContent = "REA browser verification passed.";
  message.dataset.state = "changed";
}
document.getElementById("change-button").addEventListener("click", changeMessage);
