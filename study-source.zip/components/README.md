# Independent motion components

Fifteen small ES modules expose `mount(host, options?)`, returning `destroy()` and any documented controls. Import modules directly or use per-site exports under `sites/*/05-components/`. A shared `core.mjs` supplies lifecycle, animation gating, Canvas and 3D projection helpers. All source is original; no third-party runtime dependency is required.

Use the root `styles.css` for the supplied visual presentation. `population-terrain.mjs` accepts numeric grids and preserves linear min/max height encoding. `variable-type.mjs` accepts a separately licensed variable font family. The WebGL particle module reports unsupported if the rendering context cannot be created.

Each component removes its listeners, observers and animation loops through `destroy()`. GPU buffers, shaders and programs are deleted by the particle component; the audio context is closed by the sampler. The gallery destroys the previous component before mounting a different one.
