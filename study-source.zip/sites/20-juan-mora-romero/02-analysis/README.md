# Mechanism and design analysis

Author documents Next.js, React Three Fiber, GSAP, an endless draggable Lab, channel split and wind-blown posters.

## Reconstruction choice

Drag a wrapping poster atlas with inertia, velocity-linked channel offsets and waving edges.

One progress value drives the scene. Pointer input is local to the scene; the shared lifecycle owns listeners and rendering. Paused/offscreen scheduling uses the existing library scheduler.

## Difference from production

Canvas channel offsets and analytic wave deformation; not a cloth physics solver, original GLSL pipeline or copied posters.

## Further work

Record actual entry controls, timings, scroll states and mobile behavior. Add real asset loading, reduced-motion alternatives and performance measurements before claiming production readiness.
