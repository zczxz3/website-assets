# Reproduce

Serve the repository root through HTTP and open `sites/20-juan-mora-romero/04-reconstruction/index.html`. Adjust the primary progress control; pointer or audio controls are optional additions. Screenshots and complete verification Evidence are retained in the GitHub verification artifact.
