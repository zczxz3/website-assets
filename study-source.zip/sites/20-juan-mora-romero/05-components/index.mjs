export {mount} from '../../../components/infinite-posters.mjs';
