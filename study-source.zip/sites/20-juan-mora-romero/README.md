# 20. Juan Mora Romero

Original: https://juanmoraromero.com/

Author case study: https://tympanus.net/codrops/2026/10/22/juan-mora-romero-portfolio/

## Evidence

Author documents Next.js, React Three Fiber, GSAP, an endless draggable Lab, channel split and wind-blown posters.

Public text entry was reviewed; live interaction capture is separately recorded. The article is author evidence, not a claim that all production behavior was exercised.

## Independent implementation

Drag a wrapping poster atlas with inertia, velocity-linked channel offsets and waving edges.

Module: `components/infinite-posters.mjs`, shared implementation: `components/batch-two.mjs`. API: `mount(host)` returns `destroy()`. Include `styles.css`.

## Limits

Canvas channel offsets and analytic wave deformation; not a cloth physics solver, original GLSL pipeline or copied posters.

Status: component prototype implemented; desktop/mobile verification pending.
