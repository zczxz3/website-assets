# NIPPON COLORS

Original website: https://nipponcolors.com/

**Status:** first-pass analysis and an independent runnable component prototype. Original browser evidence: complete bounded scenario. Full production-site reconstruction: **not completed**.

- [Original references and captured structure](01-original/references.json)
- [Visual, technical and motion analysis](02-analysis/README.md)
- [Asset provenance](03-assets/README.md)
- [Standalone demo source](04-reconstruction/index.html)
- [Reusable component export](05-components/index.mjs)
- [Reproduction and verification](06-demo/README.md)

## Stack and principle

Theme state / contrast-aware labels / CSS interpolation. The implementation is in [the shared module](../../components/color-theme.mjs), uses native browser APIs, and requires no runtime package installation. Import `mount(host)` to use it independently and call the returned `destroy()` before removing it or replacing the view.

## Scope

The demo palette and layout are original. The selected technique is synchronized color presentation, not a copy of the original palette database.

Observed script references include jQuery and the site script. The public page exposes named colors and RGB/CMYK fields. This independent implementation uses native DOM and CSS.

The source screenshot and third-party links are research references, not reusable production assets. Original independent source code is licensed under the repository's MIT license; third-party materials retain their own rights.
