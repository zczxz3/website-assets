# LOW←TECH MAGAZINE

Original website: https://solar.lowtechmagazine.com/

**Status:** first-pass analysis and an independent runnable component prototype. Original browser evidence: complete bounded scenario. Full production-site reconstruction: **not completed**.

- [Original references and captured structure](01-original/references.json)
- [Visual, technical and motion analysis](02-analysis/README.md)
- [Asset provenance](03-assets/README.md)
- [Standalone demo source](04-reconstruction/index.html)
- [Reusable component export](05-components/index.mjs)
- [Reproduction and verification](06-demo/README.md)

## Stack and principle

Bayer matrix / Floyd–Steinberg / PNG export. The implementation is in [the shared module](../../components/dither-image.mjs), uses native browser APIs, and requires no runtime package installation. Import `mount(host)` to use it independently and call the returned `destroy()` before removing it or replacing the view.

## Scope

No third-party image is bundled. The original publishing theme is Hugo and AGPL-3.0; this independently written image component does not incorporate its code.

Primary repository documents Hugo >=0.145 and AGPL-3.0 theme code. The captured page includes the publication layout and dithered imagery; one page error occurred and is retained as a limitation. The independent component contains no theme code.

The source screenshot and third-party links are research references, not reusable production assets. Original independent source code is licensed under the repository's MIT license; third-party materials retain their own rights.
