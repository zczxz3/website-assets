# Short Trip

Original website: https://alexanderperrin.com.au/paper/shorttrip/

**Status:** first-pass analysis and an independent runnable component prototype. Original browser evidence: complete bounded scenario. Full production-site reconstruction: **not completed**.

- [Original references and captured structure](01-original/references.json)
- [Visual, technical and motion analysis](02-analysis/README.md)
- [Asset provenance](03-assets/README.md)
- [Standalone demo source](04-reconstruction/index.html)
- [Reusable component export](05-components/index.mjs)
- [Reproduction and verification](06-demo/README.md)

## Stack and principle

Delta-time motion / input / parallax. The implementation is in [the shared module](../../components/scene-scroller.mjs), uses native browser APIs, and requires no runtime package installation. Import `mount(host)` to use it independently and call the returned `destroy()` before removing it or replacing the view.

## Scope

Original procedural scenery and a simplified vehicle are supplied. This does not reconstruct Short Trip's artwork, route, characters or game engine.

Primary page documents left/right hold controls, eco quality and audio toggles. The capture shows a Steam promotion overlay and a canvas; gameplay progression was not yet verified.

The source screenshot and third-party links are research references, not reusable production assets. Original independent source code is licensed under the repository's MIT license; third-party materials retain their own rights.

## Follow-up observation

The Play Web Version entry was activated and the illustrated web scene became visible. Audio enablement and a complete route were not exercised.
