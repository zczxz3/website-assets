# Short Trip: analysis

## Evidence and confidence

- Original: https://alexanderperrin.com.au/paper/shorttrip/
- Observation: `2026-11-04T00:56:21.303374+00:00`
- Browser result: **complete bounded scenario**. Scope: initial view, PageDown and a short settlement period.
- Static subset: **not-run**; parsed files: not measured; parse failures: not measured.
- Last retained nonempty DOM: 1 canvas element(s), 2 image element(s), 0 observed page error(s).

Primary page documents left/right hold controls, eco quality and audio toggles. The capture shows a Steam promotion overlay and a canvas; gameplay progression was not yet verified.

The initial collector uses `captured` for successful CLI exit codes. The status above additionally checks REA completeness; an exit code of zero alone is not accepted as complete capture.

## Selected mechanism

Move a tram through a layered drawn landscape. Velocity and scenery update from the same elapsed time.

Implementation: **Delta-time motion / input / parallax**. Input is mapped to a small explicit state, which drives geometry or style updates. The component owns its event handlers and rendering resources and exposes `destroy()` for teardown. Animation frames are gated by viewport intersection and page visibility. Ambient motion respects the system preference and the gallery pause control.

## Visual design

The study brief emphasizes playable scene. The independent demo uses an original visual system and procedural assets. The adjacent reference image records the observed production view; it is not a claim of visual equivalence. The original opening gate or loading state may hide later behaviors. Source-documented mechanisms and inferred reconstruction choices remain separate.

## Resource evidence

- `static/bundle20201224.js`

String fingerprints, HTML classes and a canvas count do not alone establish an active runtime dependency. See `01-original/collector-report.json` for bounded CSS measurements and code-string signals.

## Reconstruction and practical limits

Original procedural scenery and a simplified vehicle are supplied. This does not reconstruct Short Trip's artwork, route, characters or game engine.

Hold the left/right buttons or focus the scene and use arrow keys. Release or blur the scene to stop input. The distance output should change.

This is a runnable component-level reconstruction of selected principles, not a complete or pixel-identical reconstruction of the production website. Remaining production-specific features include exact timing, content, all routes, complete asset loading, pointer-specific effects, mobile behavior and field-data integration where applicable.
