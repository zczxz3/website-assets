# Mechanism and design analysis

Author describes a printed comic adapted into a scroll-driven WebGL experience.

## Reconstruction choice

Five original illustrated panels move along a horizontal rail controlled by progress.

One progress value drives the scene. Pointer input is local to the scene; the shared lifecycle owns listeners and rendering. Paused/offscreen scheduling uses the existing library scheduler.

## Difference from production

DOM rail and procedural SVG illustrations; no recovered comic artwork, fBm background or original WebGL scene.

## Further work

Record actual entry controls, timings, scroll states and mobile behavior. Add real asset loading, reduced-motion alternatives and performance measurements before claiming production readiness.
