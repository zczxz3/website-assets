# 18. Ten Years Away

Original: https://ten.375.studio/

Author case study: https://tympanus.net/codrops/2026/07/08/ten-years-away-designing-an-interactive-comic-for-studio375s-tenth-anniversary/

## Evidence

Author describes a printed comic adapted into a scroll-driven WebGL experience.

Public text entry was reviewed; live interaction capture is separately recorded. The article is author evidence, not a claim that all production behavior was exercised.

## Independent implementation

Five original illustrated panels move along a horizontal rail controlled by progress.

Module: `components/comic-rail.mjs`, shared implementation: `components/batch-two.mjs`. API: `mount(host)` returns `destroy()`. Include `styles.css`.

## Limits

DOM rail and procedural SVG illustrations; no recovered comic artwork, fBm background or original WebGL scene.

Status: component prototype implemented; desktop/mobile verification pending.
