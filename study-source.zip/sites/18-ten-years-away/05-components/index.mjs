export {mount} from '../../../components/comic-rail.mjs';
