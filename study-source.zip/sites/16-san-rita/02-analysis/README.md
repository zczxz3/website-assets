# Mechanism and design analysis

Author documents Next.js, React Three Fiber, Blender height-map topology, DatoCMS and Lenis.

## Reconstruction choice

Projected triangle mesh, procedural elevation, drag rotation and a trail marker.

One progress value drives the scene. Pointer input is local to the scene; the shared lifecycle owns listeners and rendering. Paused/offscreen scheduling uses the existing library scheduler.

## Difference from production

Synthetic terrain with Canvas projection; no geographic height-map data, baked textures, production camera paths or routing.

## Further work

Record actual entry controls, timings, scroll states and mobile behavior. Add real asset loading, reduced-motion alternatives and performance measurements before claiming production readiness.
