# Asset provenance

All demo geometry, drawings, shaders and generated tones are independently written. No original photographs, posters, sound recordings, font files, commercial models or production textures are redistributed. Reference captures retain third-party rights.
