# 16. San Rita

Original: https://sanrita.ca/

Author case study: https://tympanus.net/codrops/2026/03/24/digital-craft-wild-soul-building-san-ritas-topographic-web-experience/

## Evidence

Author documents Next.js, React Three Fiber, Blender height-map topology, DatoCMS and Lenis.

Public text entry was reviewed; live interaction capture is separately recorded. The article is author evidence, not a claim that all production behavior was exercised.

## Independent implementation

Projected triangle mesh, procedural elevation, drag rotation and a trail marker.

Module: `components/topographic-trail.mjs`, shared implementation: `components/batch-two.mjs`. API: `mount(host)` returns `destroy()`. Include `styles.css`.

## Limits

Synthetic terrain with Canvas projection; no geographic height-map data, baked textures, production camera paths or routing.

Status: component prototype implemented; current verification is in the repository-root STUDY_VERIFICATION.md.

## Bounded original capture

Map labels and markers visible; full terrain texture behavior not exercised. HTTP: 200; browser: captured; static subset: failed.
