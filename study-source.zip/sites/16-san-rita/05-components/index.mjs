export {mount} from '../../../components/topographic-trail.mjs';
