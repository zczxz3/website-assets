# Mechanical Watch

Original website: https://ciechanow.ski/mechanical-watch/

**Status:** first-pass analysis and an independent runnable component prototype. Original browser evidence: complete bounded scenario. Full production-site reconstruction: **not completed**.

- [Original references and captured structure](01-original/references.json)
- [Visual, technical and motion analysis](02-analysis/README.md)
- [Asset provenance](03-assets/README.md)
- [Standalone demo source](04-reconstruction/index.html)
- [Reusable component export](05-components/index.mjs)
- [Reproduction and verification](06-demo/README.md)

## Stack and principle

Gear ratios / exploded view / 3D projection. The implementation is in [the shared module](../../components/mechanism-section.mjs), uses native browser APIs, and requires no runtime package installation. Import `mount(host)` to use it independently and call the returned `destroy()` before removing it or replacing the view.

## Scope

This is an illustrative gear train, not a mechanically complete watch movement or a recovered original CAD model.

Primary-page documented: drag-to-rotate and slider-driven examination. Runtime DOM contains many canvas figures. The bounded common script passed parsing; this does not prove the identity of the rendering engine.

The source screenshot and third-party links are research references, not reusable production assets. Original independent source code is licensed under the repository's MIT license; third-party materials retain their own rights.
