# Demo and verification

Serve the repository root with `python3 -m http.server 8000`, then open `/sites/14-mechanical-watch/04-reconstruction/index.html`.

## Reproduction

Drag to rotate and change the exploded-view slider. Gear rotation rates follow inverse tooth counts, but the geometry is illustrative and not a physically meshing complete movement.

## Browser checks

`verify_studies.py` uses the real REA CLI against a loopback HTTP server at desktop width 1280 and mobile width 390. It checks successful initialization, an observable state change after interaction, complete browser Evidence, zero page errors and screenshot integrity. Results are measured by the Verify independent studies workflow; the presence of this file alone is not a test-pass claim.

Review screenshots for layout defects and the stated differences from the original. Run `node --test component-tests.mjs` for independent algorithm invariants. No benchmark or performance score is claimed from these functional tests.
