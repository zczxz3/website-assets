# Mechanical Watch: analysis

## Evidence and confidence

- Original: https://ciechanow.ski/mechanical-watch/
- Observation: `2026-11-04T00:56:38.532888+00:00`
- Browser result: **complete bounded scenario**. Scope: initial view, PageDown and a short settlement period.
- Static subset: **completed**; parsed files: 1; parse failures: 0.
- Last retained nonempty DOM: 93 canvas element(s), 13 image element(s), 0 observed page error(s).

Primary-page documented: drag-to-rotate and slider-driven examination. Runtime DOM contains many canvas figures. The bounded common script passed parsing; this does not prove the identity of the rendering engine.

The initial collector uses `captured` for successful CLI exit codes. The status above additionally checks REA completeness; an exit code of zero alone is not accepted as complete capture.

## Selected mechanism

Rotate an illustrated gear train and separate its layers with a continuous section control.

Implementation: **Gear ratios / exploded view / 3D projection**. Input is mapped to a small explicit state, which drives geometry or style updates. The component owns its event handlers and rendering resources and exposes `destroy()` for teardown. Animation frames are gated by viewport intersection and page visibility. Ambient motion respects the system preference and the gallery pause control.

## Visual design

The study brief emphasizes exploded diagram. The independent demo uses an original visual system and procedural assets. The adjacent reference image records the observed production view; it is not a claim of visual equivalence. The original opening gate or loading state may hide later behaviors. Source-documented mechanisms and inferred reconstruction choices remain separate.

## Resource evidence

- `https://www.googletagmanager.com/gtag/js?id=UA-25335284-3`
- `/js/base.js`
- `/js/watch.js`

String fingerprints, HTML classes and a canvas count do not alone establish an active runtime dependency. See `01-original/collector-report.json` for bounded CSS measurements and code-string signals.

## Reconstruction and practical limits

This is an illustrative gear train, not a mechanically complete watch movement or a recovered original CAD model.

Drag to rotate and change the exploded-view slider. Gear rotation rates follow inverse tooth counts, but the geometry is illustrative and not a physically meshing complete movement.

This is a runnable component-level reconstruction of selected principles, not a complete or pixel-identical reconstruction of the production website. Remaining production-specific features include exact timing, content, all routes, complete asset loading, pointer-specific effects, mobile behavior and field-data integration where applicable.
