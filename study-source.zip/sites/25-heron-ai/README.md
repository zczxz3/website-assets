# 25. Heron AI

Original: https://heronaiapp.com/

Author case study: https://tympanus.net/codrops/2026/10/12/heron-ai/

## Evidence

Author describes architectural drawings, annotations and an Observe–Advise–Act–Learn homepage; article tags GSAP.

Public text entry was reviewed; live interaction capture is separately recorded. The article is author evidence, not a claim that all production behavior was exercised.

## Independent implementation

A technical drawing reveals geometry, annotations and corrective highlights across a four-step workflow.

Module: `components/blueprint-workflow.mjs`, shared implementation: `components/batch-two.mjs`. API: `mount(host)` returns `destroy()`. Include `styles.css`.

## Limits

Canvas illustration only; no actual code-compliance engine, BIM integration or product agent.

Status: component prototype implemented; desktop/mobile verification pending.
