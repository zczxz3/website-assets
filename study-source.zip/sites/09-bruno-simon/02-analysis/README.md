# Bruno Simon: analysis

## Evidence and confidence

- Original: https://bruno-simon.com/
- Observation: `2026-11-04T00:55:10.692514+00:00`
- Browser result: **partial bounded scenario**. Scope: initial view, PageDown and a short settlement period.
- Static subset: **not-run**; parsed files: not measured; parse failures: not measured.
- Last retained nonempty DOM: 1 canvas element(s), 44 image element(s), 0 observed page error(s).

Primary-site documented: Three.js, TSL, WebGL/WebGPU, Rapier and Howler.js. Source repository is MIT-licensed according to its own page. First browser result is incomplete and shows loading; the full vehicle world was not verified in that capture.

The initial collector uses `captured` for successful CLI exit codes. The status above additionally checks REA completeness; an exit code of zero alone is not accepted as complete capture.

## Selected mechanism

A small vehicle moves through an original projected world with obstacle resolution and a damped following camera.

Implementation: **Kinematic bicycle / collision / 3D projection**. Input is mapped to a small explicit state, which drives geometry or style updates. The component owns its event handlers and rendering resources and exposes `destroy()` for teardown. Animation frames are gated by viewport intersection and page visibility. Ambient motion respects the system preference and the gallery pause control.

## Visual design

The study brief emphasizes interactive 3d. The independent demo uses an original visual system and procedural assets. The adjacent reference image records the observed production view; it is not a claim of visual equivalence. The original opening gate or loading state may hide later behaviors. Source-documented mechanisms and inferred reconstruction choices remain separate.

## Resource evidence

- `https://www.googletagmanager.com/gtag/js?id=G-JMSN30BQ5J`
- `./assets/index-ORr3L4no.js`

String fingerprints, HTML classes and a canvas count do not alone establish an active runtime dependency. See `01-original/collector-report.json` for bounded CSS measurements and code-string signals.

## Reconstruction and practical limits

This is a deliberately small CPU-projected 3D prototype. Bruno's current production project uses Three.js with WebGL/WebGPU and Rapier, confirmed by its own technical page. This does not reproduce that renderer or physics engine.

Drive with on-screen controls or focus the scene and use arrow keys. Test obstacle resolution, camera following and Reset. This is a simplified kinematic simulation.

This is a runnable component-level reconstruction of selected principles, not a complete or pixel-identical reconstruction of the production website. Remaining production-specific features include exact timing, content, all routes, complete asset loading, pointer-specific effects, mobile behavior and field-data integration where applicable.
