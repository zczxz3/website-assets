# Bruno Simon

Original website: https://bruno-simon.com/

**Status:** first-pass analysis and an independent runnable component prototype. Original browser evidence: partial bounded scenario. Full production-site reconstruction: **not completed**.

- [Original references and captured structure](01-original/references.json)
- [Visual, technical and motion analysis](02-analysis/README.md)
- [Asset provenance](03-assets/README.md)
- [Standalone demo source](04-reconstruction/index.html)
- [Reusable component export](05-components/index.mjs)
- [Reproduction and verification](06-demo/README.md)

## Stack and principle

Kinematic bicycle / collision / 3D projection. The implementation is in [the shared module](../../components/vehicle-world.mjs), uses native browser APIs, and requires no runtime package installation. Import `mount(host)` to use it independently and call the returned `destroy()` before removing it or replacing the view.

## Scope

This is a deliberately small CPU-projected 3D prototype. Bruno's current production project uses Three.js with WebGL/WebGPU and Rapier, confirmed by its own technical page. This does not reproduce that renderer or physics engine.

Primary-site documented: Three.js, TSL, WebGL/WebGPU, Rapier and Howler.js. Source repository is MIT-licensed according to its own page. First browser result is incomplete and shows loading; the full vehicle world was not verified in that capture.

The source screenshot and third-party links are research references, not reusable production assets. Original independent source code is licensed under the repository's MIT license; third-party materials retain their own rights.
