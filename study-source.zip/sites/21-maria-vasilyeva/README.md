# 21. Maria Vasilyeva

Original: https://www.mariavasilyeva.com/

Author case study: https://tympanus.net/codrops/2026/10/20/maria-vasilyeva-portfolio/

## Evidence

Author describes music as the organizing framework for layout, movement and sound.

Public text entry was reviewed; live interaction capture is separately recorded. The article is author evidence, not a claim that all production behavior was exercised.

## Independent implementation

An eight-note composition ties visual selection and explicitly enabled synthesized sound to one progress value.

Module: `components/melody-grid.mjs`, shared implementation: `components/batch-two.mjs`. API: `mount(host)` returns `destroy()`. Include `styles.css`.

## Limits

Synthesized tones and Canvas bars; no original recordings, project images or recovered production audio engine.

Status: component prototype implemented; current verification is in the repository-root STUDY_VERIFICATION.md.

## Bounded original capture

Horizontal project-note composition visible; original audio not enabled. HTTP: 200; browser: captured; static subset: completed.
