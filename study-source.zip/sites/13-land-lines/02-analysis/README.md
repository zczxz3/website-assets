# Land Lines: analysis

## Evidence and confidence

- Original: https://lines.chromeexperiments.com/
- Observation: `2026-11-04T00:56:34.356298+00:00`
- Browser result: **complete bounded scenario**. Scope: initial view, PageDown and a short settlement period.
- Static subset: **not-run**; parsed files: not measured; parse failures: not measured.
- Last retained nonempty DOM: 1 canvas element(s), 3 image element(s), 0 observed page error(s).

Primary-page documented: Pixi.js/WebGL, a vantage point tree and preprocessing with line-detection tools. The Draw/Drag entry view was captured. The prototype does not include Google Earth imagery.

The initial collector uses `captured` for successful CLI exit codes. The status above additionally checks REA completeness; an exit code of zero alone is not accepted as complete capture.

## Selected mechanism

Resampled strokes are normalized and compared against a small procedural atlas, independent of scale and drawing direction.

Implementation: **Polyline resampling / normalized distance / pointer input**. Input is mapped to a small explicit state, which drives geometry or style updates. The component owns its event handlers and rendering resources and exposes `destroy()` for teardown. Animation frames are gated by viewport intersection and page visibility. Ambient motion respects the system preference and the gallery pause control.

## Visual design

The study brief emphasizes geometric matching. The independent demo uses an original visual system and procedural assets. The adjacent reference image records the observed production view; it is not a claim of visual equivalence. The original opening gate or loading state may hide later behaviors. Source-documented mechanisms and inferred reconstruction choices remain separate.

## Resource evidence

- No external script URL was present in the retained initial HTML subset.

String fingerprints, HTML classes and a canvas count do not alone establish an active runtime dependency. See `01-original/collector-report.json` for bounded CSS measurements and code-string signals.

## Reconstruction and practical limits

The original project uses preprocessed satellite imagery, a vantage point tree and Pixi.js. This prototype uses original procedural shapes and exact search over three candidates, with no satellite image dataset.

Draw a continuous line or choose the example stroke. Compare normalized distances, then clear the drawing. Only three original procedural candidates are searched.

This is a runnable component-level reconstruction of selected principles, not a complete or pixel-identical reconstruction of the production website. Remaining production-specific features include exact timing, content, all routes, complete asset loading, pointer-specific effects, mobile behavior and field-data integration where applicable.

## Targeted follow-up

Activating Draw displayed the drawing mode and gesture prompt. A full original satellite matching interaction was not exercised. See the follow-up Evidence in `01-original/`.
