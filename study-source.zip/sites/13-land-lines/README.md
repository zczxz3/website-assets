# Land Lines

Original website: https://lines.chromeexperiments.com/

**Status:** first-pass analysis and an independent runnable component prototype. Original browser evidence: complete bounded scenario. Full production-site reconstruction: **not completed**.

- [Original references and captured structure](01-original/references.json)
- [Visual, technical and motion analysis](02-analysis/README.md)
- [Asset provenance](03-assets/README.md)
- [Standalone demo source](04-reconstruction/index.html)
- [Reusable component export](05-components/index.mjs)
- [Reproduction and verification](06-demo/README.md)

## Stack and principle

Polyline resampling / normalized distance / pointer input. The implementation is in [the shared module](../../components/stroke-matcher.mjs), uses native browser APIs, and requires no runtime package installation. Import `mount(host)` to use it independently and call the returned `destroy()` before removing it or replacing the view.

## Scope

The original project uses preprocessed satellite imagery, a vantage point tree and Pixi.js. This prototype uses original procedural shapes and exact search over three candidates, with no satellite image dataset.

Primary-page documented: Pixi.js/WebGL, a vantage point tree and preprocessing with line-detection tools. The Draw/Drag entry view was captured. The prototype does not include Google Earth imagery.

The source screenshot and third-party links are research references, not reusable production assets. Original independent source code is licensed under the repository's MIT license; third-party materials retain their own rights.

## Follow-up observation

Activating Draw displayed the drawing mode and gesture prompt. A full original satellite matching interaction was not exercised.
