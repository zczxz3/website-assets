# The Boat: analysis

## Evidence and confidence

- Original: https://www.sbs.com.au/theboat/
- Observation: `2026-11-04T00:54:50.130017+00:00`
- Browser result: **complete bounded scenario**. Scope: initial view, PageDown and a short settlement period.
- Static subset: **completed**; parsed files: 2; parse failures: 0.
- Last retained nonempty DOM: 1 canvas element(s), 2 image element(s), 0 observed page error(s).

Observed: a start screen with a canvas and runtime scroll-manager containers; the supplied script subset passed REA parsing. Narrative progression beyond the initial gate was not inspected in this first pass.

The initial collector uses `captured` for successful CLI exit codes. The status above additionally checks REA completeness; an exit code of zero alone is not accepted as complete capture.

## Selected mechanism

Ink-like marks, terrain layers and typography share one narrative progress value.

Implementation: **Canvas layers / scroll progress / parallax**. Input is mapped to a small explicit state, which drives geometry or style updates. The component owns its event handlers and rendering resources and exposes `destroy()` for teardown. Animation frames are gated by viewport intersection and page visibility. Ambient motion respects the system preference and the gallery pause control.

## Visual design

The study brief emphasizes scroll narrative. The independent demo uses an original visual system and procedural assets. The adjacent reference image records the observed production view; it is not a claim of visual equivalence. The original opening gate or loading state may hide later behaviors. Source-documented mechanisms and inferred reconstruction choices remain separate.

## Resource evidence

- `scripts/vendor/modernizr/modernizr.js`
- `scripts/vendor/detectizr/detectizr.js`
- `scripts/flightcheck.js`
- `scripts/main.js`
- `//nexus.ensighten.com/sbs/prod/Bootstrap.js`

String fingerprints, HTML classes and a canvas count do not alone establish an active runtime dependency. See `01-original/collector-report.json` for bounded CSS measurements and code-string signals.

## Reconstruction and practical limits

The original page was captured at its opening state. This is a technique study with procedural illustration, without SBS artwork, story text or sound.

Scroll within the scene or use the narrative progress slider. Ink texture, depth layers and text should respond to the shared progress value.

This is a runnable component-level reconstruction of selected principles, not a complete or pixel-identical reconstruction of the production website. Remaining production-specific features include exact timing, content, all routes, complete asset loading, pointer-specific effects, mobile behavior and field-data integration where applicable.
