# The Boat

Original website: https://www.sbs.com.au/theboat/

**Status:** first-pass analysis and an independent runnable component prototype. Original browser evidence: complete bounded scenario. Full production-site reconstruction: **not completed**.

- [Original references and captured structure](01-original/references.json)
- [Visual, technical and motion analysis](02-analysis/README.md)
- [Asset provenance](03-assets/README.md)
- [Standalone demo source](04-reconstruction/index.html)
- [Reusable component export](05-components/index.mjs)
- [Reproduction and verification](06-demo/README.md)

## Stack and principle

Canvas layers / scroll progress / parallax. The implementation is in [the shared module](../../components/ink-story.mjs), uses native browser APIs, and requires no runtime package installation. Import `mount(host)` to use it independently and call the returned `destroy()` before removing it or replacing the view.

## Scope

The original page was captured at its opening state. This is a technique study with procedural illustration, without SBS artwork, story text or sound.

Observed: a start screen with a canvas and runtime scroll-manager containers; the supplied script subset passed REA parsing. Narrative progression beyond the initial gate was not inspected in this first pass.

The source screenshot and third-party links are research references, not reusable production assets. Original independent source code is licensed under the repository's MIT license; third-party materials retain their own rights.
