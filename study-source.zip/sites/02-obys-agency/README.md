# Obys Agency

Original website: https://obys.agency/

**Status:** first-pass analysis and an independent runnable component prototype. Original browser evidence: complete bounded scenario. Full production-site reconstruction: **not completed**.

- [Original references and captured structure](01-original/references.json)
- [Visual, technical and motion analysis](02-analysis/README.md)
- [Asset provenance](03-assets/README.md)
- [Standalone demo source](04-reconstruction/index.html)
- [Reusable component export](05-components/index.mjs)
- [Reproduction and verification](06-demo/README.md)

## Stack and principle

Clipped text / stagger / layout state. The implementation is in [the shared module](../../components/text-reveal.mjs), uses native browser APIs, and requires no runtime package installation. Import `mount(host)` to use it independently and call the returned `destroy()` before removing it or replacing the view.

## Scope

Selected typographic techniques are independently rebuilt. The exact Obys production timeline and pointer shader are not reproduced.

Observed: a canvas, a large project catalog and image/video content. The exact active animation dependencies are unverified by the bounded first capture.

The source screenshot and third-party links are research references, not reusable production assets. Original independent source code is licensed under the repository's MIT license; third-party materials retain their own rights.
