# Asset provenance

The runnable text masks study uses original CSS, procedural geometry, generated illustration, or synthesized audio. The visual assets are defined in `../../../components/text-reveal.mjs` and the shared stylesheet. No production photographs, original commercial fonts, original story text, sound samples, logos, satellite tiles or complete population/weather datasets are included.

`../01-original/reference.jpg` is a bounded research screenshot of the original website. Its copyright remains with the original owners. It is reference evidence and is not an asset licensed for reuse. Linked source repositories keep their own licenses; those do not automatically cover third-party content or imagery.
