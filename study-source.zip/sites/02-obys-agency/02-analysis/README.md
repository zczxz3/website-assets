# Obys Agency: analysis

## Evidence and confidence

- Original: https://obys.agency/
- Observation: `2026-11-04T00:54:50.129876+00:00`
- Browser result: **complete bounded scenario**. Scope: initial view, PageDown and a short settlement period.
- Static subset: **not-run**; parsed files: not measured; parse failures: not measured.
- Last retained nonempty DOM: 1 canvas element(s), 38 image element(s), 0 observed page error(s).

Observed: a canvas, a large project catalog and image/video content. The exact active animation dependencies are unverified by the bounded first capture.

The initial collector uses `captured` for successful CLI exit codes. The status above additionally checks REA completeness; an exit code of zero alone is not accepted as complete capture.

## Selected mechanism

Staggered text enters through clipped lines. Switch the composition without losing the same content.

Implementation: **Clipped text / stagger / layout state**. Input is mapped to a small explicit state, which drives geometry or style updates. The component owns its event handlers and rendering resources and exposes `destroy()` for teardown. Animation frames are gated by viewport intersection and page visibility. Ambient motion respects the system preference and the gallery pause control.

## Visual design

The study brief emphasizes text masks. The independent demo uses an original visual system and procedural assets. The adjacent reference image records the observed production view; it is not a claim of visual equivalence. The original opening gate or loading state may hide later behaviors. Source-documented mechanisms and inferred reconstruction choices remain separate.

## Resource evidence

- `https://www.googletagmanager.com/gtag/js?id=G-L16SCYVMS7`

String fingerprints, HTML classes and a canvas count do not alone establish an active runtime dependency. See `01-original/collector-report.json` for bounded CSS measurements and code-string signals.

## Reconstruction and practical limits

Selected typographic techniques are independently rebuilt. The exact Obys production timeline and pointer shader are not reproduced.

Replay the masked typography and toggle between two compositions. With reduced motion enabled, the final text appears immediately.

This is a runnable component-level reconstruction of selected principles, not a complete or pixel-identical reconstruction of the production website. Remaining production-specific features include exact timing, content, all routes, complete asset loading, pointer-specific effects, mobile behavior and field-data integration where applicable.
