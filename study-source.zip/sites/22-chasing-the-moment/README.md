# 22. Chasing the Moment

Original: https://chasing-the-moment.byholm.co/

Author case study: https://tympanus.net/codrops/2026/10/12/chasing-the-moment/

## Evidence

Author documents a five-stage browser webfilm made with Three.js and GLSL.

Public text entry was reviewed; live interaction capture is separately recorded. The article is author evidence, not a claim that all production behavior was exercised.

## Independent implementation

A procedural runner cycles through a projected city while a progress track changes camera framing.

Module: `components/runner-camera.mjs`, shared implementation: `components/batch-two.mjs`. API: `mount(host)` returns `destroy()`. Include `styles.css`.

## Limits

Simplified stick figure and CPU projection; no original rig, full five-scene film or shattering postprocessing.

Status: component prototype implemented; current verification is in the repository-root STUDY_VERIFICATION.md.

## Bounded original capture

Intro graphic visible, but capture incomplete after initial state. HTTP: 200; browser: partial; static subset: completed.
