# Mechanism and design analysis

Author documents a five-stage browser webfilm made with Three.js and GLSL.

## Reconstruction choice

A procedural runner cycles through a projected city while a progress track changes camera framing.

One progress value drives the scene. Pointer input is local to the scene; the shared lifecycle owns listeners and rendering. Paused/offscreen scheduling uses the existing library scheduler.

## Difference from production

Simplified stick figure and CPU projection; no original rig, full five-scene film or shattering postprocessing.

## Further work

Record actual entry controls, timings, scroll states and mobile behavior. Add real asset loading, reduced-motion alternatives and performance measurements before claiming production readiness.
