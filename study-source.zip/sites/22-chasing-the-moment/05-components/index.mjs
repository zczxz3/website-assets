export {mount} from '../../../components/runner-camera.mjs';
