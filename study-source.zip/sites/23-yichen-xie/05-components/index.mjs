export {mount} from '../../../components/sdf-bubbles.mjs';
