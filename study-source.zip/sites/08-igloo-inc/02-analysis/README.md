# Igloo Inc.: analysis

## Evidence and confidence

- Original: https://www.igloo.inc/
- Observation: `2026-11-04T00:55:03.827807+00:00`
- Browser result: **partial bounded scenario**. Scope: initial view, PageDown and a short settlement period.
- Static subset: **completed**; parsed files: 1; parse failures: 0.
- Last retained nonempty DOM: 0 canvas element(s), 0 image element(s), 0 observed page error(s).

The original result is incomplete: a sparse loading view was captured, then the PageDown action failed. One bounded script passed static analysis. No claim about the active production particle engine is made.

The initial collector uses `captured` for successful CLI exit codes. The status above additionally checks REA completeness; an exit code of zero alone is not accepted as complete capture.

## Selected mechanism

Thousands of GPU points interpolate between a sphere and a torus while the view responds to the pointer.

Implementation: **WebGL / GLSL / point buffers / interpolation**. Input is mapped to a small explicit state, which drives geometry or style updates. The component owns its event handlers and rendering resources and exposes `destroy()` for teardown. Animation frames are gated by viewport intersection and page visibility. Ambient motion respects the system preference and the gallery pause control.

## Visual design

The study brief emphasizes webgl particles. The independent demo uses an original visual system and procedural assets. The adjacent reference image records the observed production view; it is not a claim of visual equivalence. The original opening gate or loading state may hide later behaviors. Source-documented mechanisms and inferred reconstruction choices remain separate.

## Resource evidence

- `https://www.igloo.inc/assets/index-2e130bc1.js`

String fingerprints, HTML classes and a canvas count do not alone establish an active runtime dependency. See `01-original/collector-report.json` for bounded CSS measurements and code-string signals.

## Reconstruction and practical limits

The first original capture was incomplete and showed a sparse loading state. The particle technique is an independent study; the exact Igloo shader is unverified.

Adjust the shape slider and move the pointer. Verify sphere-to-torus interpolation. On a device without WebGL the component reports unsupported rather than claiming a render.

This is a runnable component-level reconstruction of selected principles, not a complete or pixel-identical reconstruction of the production website. Remaining production-specific features include exact timing, content, all routes, complete asset loading, pointer-specific effects, mobile behavior and field-data integration where applicable.

## Targeted follow-up

A longer observation completed without the PageDown action, but the retained viewport remained a flat sparse loading state. Complete capture does not establish successful 3D rendering. See the follow-up Evidence in `01-original/`.
