# Igloo Inc.

Original website: https://www.igloo.inc/

**Status:** first-pass analysis and an independent runnable component prototype. Original browser evidence: partial bounded scenario. Full production-site reconstruction: **not completed**.

- [Original references and captured structure](01-original/references.json)
- [Visual, technical and motion analysis](02-analysis/README.md)
- [Asset provenance](03-assets/README.md)
- [Standalone demo source](04-reconstruction/index.html)
- [Reusable component export](05-components/index.mjs)
- [Reproduction and verification](06-demo/README.md)

## Stack and principle

WebGL / GLSL / point buffers / interpolation. The implementation is in [the shared module](../../components/particle-morph.mjs), uses native browser APIs, and requires no runtime package installation. Import `mount(host)` to use it independently and call the returned `destroy()` before removing it or replacing the view.

## Scope

The first original capture was incomplete and showed a sparse loading state. The particle technique is an independent study; the exact Igloo shader is unverified.

The original result is incomplete: a sparse loading view was captured, then the PageDown action failed. One bounded script passed static analysis. No claim about the active production particle engine is made.

The source screenshot and third-party links are research references, not reusable production assets. Original independent source code is licensed under the repository's MIT license; third-party materials retain their own rights.

## Follow-up observation

A longer observation completed without the PageDown action, but the retained viewport remained a flat sparse loading state. Complete capture does not establish successful 3D rendering.
