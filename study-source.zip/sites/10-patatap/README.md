# Patatap

Original website: https://patatap.com/

**Status:** first-pass analysis and an independent runnable component prototype. Original browser evidence: complete bounded scenario. Full production-site reconstruction: **not completed**.

- [Original references and captured structure](01-original/references.json)
- [Visual, technical and motion analysis](02-analysis/README.md)
- [Asset provenance](03-assets/README.md)
- [Standalone demo source](04-reconstruction/index.html)
- [Reusable component export](05-components/index.mjs)
- [Reproduction and verification](06-demo/README.md)

## Stack and principle

Canvas / Web Audio / event timing. The implementation is in [the shared module](../../components/key-visual-sampler.mjs), uses native browser APIs, and requires no runtime package installation. Import `mount(host)` to use it independently and call the returned `destroy()` before removing it or replacing the view.

## Scope

Original synthesized tones replace the original samples. The source site credits Two.js; this independent study uses Canvas and Web Audio.

Primary-site documented: Two.js, with animation/sound collaboration credited to Jono Brandel and Lullatone. The opening canvas prompt was captured; the original audio samples are not included.

The source screenshot and third-party links are research references, not reusable production assets. Original independent source code is licensed under the repository's MIT license; third-party materials retain their own rights.
