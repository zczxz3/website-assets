// Reusable independent component. No production-site asset dependency.
export {mount} from '../../../components/key-visual-sampler.mjs';
