# Patatap: analysis

## Evidence and confidence

- Original: https://patatap.com/
- Observation: `2026-11-04T00:56:23.542935+00:00`
- Browser result: **complete bounded scenario**. Scope: initial view, PageDown and a short settlement period.
- Static subset: **not-run**; parsed files: not measured; parse failures: not measured.
- Last retained nonempty DOM: 1 canvas element(s), 0 image element(s), 0 observed page error(s).

Primary-site documented: Two.js, with animation/sound collaboration credited to Jono Brandel and Lullatone. The opening canvas prompt was captured; the original audio samples are not included.

The initial collector uses `captured` for successful CLI exit codes. The status above additionally checks REA completeness; an exit code of zero alone is not accepted as complete capture.

## Selected mechanism

Keyboard notes create visual gestures; sound starts only after an explicit audio action.

Implementation: **Canvas / Web Audio / event timing**. Input is mapped to a small explicit state, which drives geometry or style updates. The component owns its event handlers and rendering resources and exposes `destroy()` for teardown. Animation frames are gated by viewport intersection and page visibility. Ambient motion respects the system preference and the gallery pause control.

## Visual design

The study brief emphasizes audio and geometry. The independent demo uses an original visual system and procedural assets. The adjacent reference image records the observed production view; it is not a claim of visual equivalence. The original opening gate or loading state may hide later behaviors. Source-documented mechanisms and inferred reconstruction choices remain separate.

## Resource evidence

- No external script URL was present in the retained initial HTML subset.

String fingerprints, HTML classes and a canvas count do not alone establish an active runtime dependency. See `01-original/collector-report.json` for bounded CSS measurements and code-string signals.

## Reconstruction and practical limits

Original synthesized tones replace the original samples. The source site credits Two.js; this independent study uses Canvas and Web Audio.

Select Play a shape or focus the scene and type A–Z. Enable sound explicitly; mute it again. There are no original sound samples or network audio requests.

This is a runnable component-level reconstruction of selected principles, not a complete or pixel-identical reconstruction of the production website. Remaining production-specific features include exact timing, content, all routes, complete asset loading, pointer-specific effects, mobile behavior and field-data integration where applicable.

## Targeted follow-up

A canvas keypress completed at the browser-action level, but the final viewport still showed the opening prompt. Original note/sound activation is not claimed. See the follow-up Evidence in `01-original/`.
