# 24. ULTRAGRID

Original: https://ultragrid.studio/

Author case study: https://tympanus.net/codrops/2026/09/30/ultragrid-portfolio/

## Evidence

Author confirms Blender modeling, Spline scene interactions, Webflow, GSAP and Osmo.

Public text entry was reviewed; live interaction capture is separately recorded. The article is author evidence, not a claim that all production behavior was exercised.

## Independent implementation

An isometric desk rotates while keyboard-accessible navigation controls emit section events.

Module: `components/isometric-office.mjs`, shared implementation: `components/batch-two.mjs`. API: `mount(host)` returns `destroy()`. Include `styles.css`.

## Limits

Procedural projected boxes and native controls; no Spline model or original desk assets. Object raycasting is not implemented.

Status: component prototype implemented; current verification is in the repository-root STUDY_VERIFICATION.md.

## Bounded original capture

Isometric desk and points of interest visible; full object navigation not exercised. HTTP: 200; browser: captured; static subset: not-run.
