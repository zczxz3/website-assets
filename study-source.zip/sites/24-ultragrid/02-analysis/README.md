# Mechanism and design analysis

Author confirms Blender modeling, Spline scene interactions, Webflow, GSAP and Osmo.

## Reconstruction choice

An isometric desk rotates while keyboard-accessible navigation controls emit section events.

One progress value drives the scene. Pointer input is local to the scene; the shared lifecycle owns listeners and rendering. Paused/offscreen scheduling uses the existing library scheduler.

## Difference from production

Procedural projected boxes and native controls; no Spline model or original desk assets. Object raycasting is not implemented.

## Further work

Record actual entry controls, timings, scroll states and mobile behavior. Add real asset loading, reduced-motion alternatives and performance measurements before claiming production readiness.
