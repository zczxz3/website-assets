export {mount} from '../../../components/isometric-office.mjs';
