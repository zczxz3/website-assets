export {mount} from '../../../components/film-distortion.mjs';
