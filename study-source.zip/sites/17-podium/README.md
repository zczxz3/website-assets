# 17. Podium

Original: https://podium.global/

Author case study: https://tympanus.net/codrops/2026/06/23/podium-building-a-website-where-running-becomes-storytelling/

## Evidence

Author documents Zustand, Next.js, React, GSAP ScrollTrigger/Flip, Lenis and Three.js/R3F.

Public text entry was reviewed; live interaction capture is separately recorded. The article is author evidence, not a claim that all production behavior was exercised.

## Independent implementation

GLSL pointer distortion and time-varying grain over an original procedural landscape.

Module: `components/film-distortion.mjs`, shared implementation: `components/batch-two.mjs`. API: `mount(host)` returns `destroy()`. Include `styles.css`.

## Limits

Procedural shader; no original films, imagery, production shared-element routing or media pipeline.

Status: component prototype implemented; current verification is in the repository-root STUDY_VERIFICATION.md.

## Bounded original capture

Opening loader remained visible; cinematic hero and project transitions not exercised. HTTP: 200; browser: captured; static subset: failed.
