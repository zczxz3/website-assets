# Mechanism and design analysis

Author documents Zustand, Next.js, React, GSAP ScrollTrigger/Flip, Lenis and Three.js/R3F.

## Reconstruction choice

GLSL pointer distortion and time-varying grain over an original procedural landscape.

One progress value drives the scene. Pointer input is local to the scene; the shared lifecycle owns listeners and rendering. Paused/offscreen scheduling uses the existing library scheduler.

## Difference from production

Procedural shader; no original films, imagery, production shared-element routing or media pipeline.

## Further work

Record actual entry controls, timings, scroll states and mobile behavior. Add real asset loading, reduced-motion alternatives and performance measurements before claiming production readiness.
