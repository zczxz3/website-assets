# Demo and verification

Serve the repository root with `python3 -m http.server 8000`, then open `/sites/01-mersi-architecture/04-reconstruction/index.html`.

## Reproduction

Select the courtyard image; verify its geometry moves into the modal. Close it with the Close button or Escape; keyboard focus returns to the source card.

## Browser checks

`verify_studies.py` uses the real REA CLI against a loopback HTTP server at desktop width 1280 and mobile width 390. It checks successful initialization, an observable state change after interaction, complete browser Evidence, zero page errors and screenshot integrity. Results are measured by the Verify independent studies workflow; the presence of this file alone is not a test-pass claim.

Review screenshots for layout defects and the stated differences from the original. Run `node --test component-tests.mjs` for independent algorithm invariants. No benchmark or performance score is claimed from these functional tests.
