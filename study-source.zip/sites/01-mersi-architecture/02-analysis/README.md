# MERSI Architecture: analysis

## Evidence and confidence

- Original: https://www.mersi-architecture.com/
- Observation: `2026-11-04T00:54:50.129992+00:00`
- Browser result: **complete bounded scenario**. Scope: initial view, PageDown and a short settlement period.
- Static subset: **failed**; parsed files: not measured; parse failures: not measured.
- Last retained nonempty DOM: 0 canvas element(s), 21 image element(s), 0 observed page error(s).

Primary-source documented: Webflow CMS; Vite-built custom JavaScript; GSAP ScrollTrigger, SplitText and Flip; Lenis; Taxi.js; Splide. The independent component uses native Web Animations, with no production-source code copied.

The initial collector uses `captured` for successful CLI exit codes. The status above additionally checks REA completeness; an exit code of zero alone is not accepted as complete capture.

## Selected mechanism

One original image moves from its card into a project dialog, preserving continuity across the layout change.

Implementation: **DOM geometry / Web Animations / dialog**. Input is mapped to a small explicit state, which drives geometry or style updates. The component owns its event handlers and rendering resources and exposes `destroy()` for teardown. Animation frames are gated by viewport intersection and page visibility. Ambient motion respects the system preference and the gallery pause control.

## Visual design

The study brief emphasizes flip transition. The independent demo uses an original visual system and procedural assets. The adjacent reference image records the observed production view; it is not a claim of visual equivalence. The original opening gate or loading state may hide later behaviors. Source-documented mechanisms and inferred reconstruction choices remain separate.

## Resource evidence

- `/haqt6iy0yx2eNjk2ODk4NDJhNDBhMTdhYzQ1ZTU0MThh/KOb4T9Uw3E6nfGm5tJ7BcGMw3jQ`
- `https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=69689842a40a17ac45e5418a`
- `https://cdn.prod.website-files.com/69689842a40a17ac45e5418a/js/webflow.schunk.ed9687e0656a5325.js`
- `https://cdn.prod.website-files.com/69689842a40a17ac45e5418a/js/webflow.eaf8ceef.4516a5108c6c615f.js`
- `https://mersi.netlify.app/main.js`

String fingerprints, HTML classes and a canvas count do not alone establish an active runtime dependency. See `01-original/collector-report.json` for bounded CSS measurements and code-string signals.

## Reconstruction and practical limits

The original author documents GSAP Flip and Taxi.js. This component independently implements the geometric principle with Web Animations. It is a single-page transition, not a routed copy.

Select the courtyard image; verify its geometry moves into the modal. Close it with the Close button or Escape; keyboard focus returns to the source card.

This is a runnable component-level reconstruction of selected principles, not a complete or pixel-identical reconstruction of the production website. Remaining production-specific features include exact timing, content, all routes, complete asset loading, pointer-specific effects, mobile behavior and field-data integration where applicable.
