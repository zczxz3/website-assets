# MERSI Architecture

Original website: https://www.mersi-architecture.com/

**Status:** first-pass analysis and an independent runnable component prototype. Original browser evidence: complete bounded scenario. Full production-site reconstruction: **not completed**.

- [Original references and captured structure](01-original/references.json)
- [Visual, technical and motion analysis](02-analysis/README.md)
- [Asset provenance](03-assets/README.md)
- [Standalone demo source](04-reconstruction/index.html)
- [Reusable component export](05-components/index.mjs)
- [Reproduction and verification](06-demo/README.md)

## Stack and principle

DOM geometry / Web Animations / dialog. The implementation is in [the shared module](../../components/shared-transition.mjs), uses native browser APIs, and requires no runtime package installation. Import `mount(host)` to use it independently and call the returned `destroy()` before removing it or replacing the view.

## Scope

The original author documents GSAP Flip and Taxi.js. This component independently implements the geometric principle with Web Animations. It is a single-page transition, not a routed copy.

Primary-source documented: Webflow CMS; Vite-built custom JavaScript; GSAP ScrollTrigger, SplitText and Flip; Lenis; Taxi.js; Splide. The independent component uses native Web Animations, with no production-source code copied.

The source screenshot and third-party links are research references, not reusable production assets. Original independent source code is licensed under the repository's MIT license; third-party materials retain their own rights.
