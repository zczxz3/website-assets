# Stripe Press: analysis

## Evidence and confidence

- Original: https://press.stripe.com/
- Observation: `2026-11-04T00:56:16.565624+00:00`
- Browser result: **complete bounded scenario**. Scope: initial view, PageDown and a short settlement period.
- Static subset: **not-run**; parsed files: not measured; parse failures: not measured.
- Last retained nonempty DOM: 2 canvas element(s), 35 image element(s), 0 observed page error(s).

Observed: two canvases and Stripe-hosted bootstrap scripts. The capture shows a stacked dimensional book presentation. The production rendering library remains unverified.

The initial collector uses `captured` for successful CLI exit codes. The status above additionally checks REA completeness; an exit code of zero alone is not accepted as complete capture.

## Selected mechanism

Move over the cover or adjust its rotation to explore a dimensional object built from lightweight planes.

Implementation: **CSS perspective / pointer mapping / keyboard range**. Input is mapped to a small explicit state, which drives geometry or style updates. The component owns its event handlers and rendering resources and exposes `destroy()` for teardown. Animation frames are gated by viewport intersection and page visibility. Ambient motion respects the system preference and the gallery pause control.

## Visual design

The study brief emphasizes css 3d object. The independent demo uses an original visual system and procedural assets. The adjacent reference image records the observed production view; it is not a claim of visual equivalence. The original opening gate or loading state may hide later behaviors. Source-documented mechanisms and inferred reconstruction choices remain separate.

## Resource evidence

- `https://b.stripecdn.com/mkt-statics-srv/assets/imt-861a8d15f2ff52282714277e64c74c35.js`
- `https://b.stripecdn.com/mkt-statics-srv/assets/v1-Bootstrapper-NUYZBWPG.js`

String fingerprints, HTML classes and a canvas count do not alone establish an active runtime dependency. See `01-original/collector-report.json` for bounded CSS measurements and code-string signals.

## Reconstruction and practical limits

This is a CSS 3D book, not a recovered Stripe model or renderer. Cover artwork and text are original.

Move the pointer over the book or use its keyboard-accessible rotation slider. Observe the cover, spine and page block under the same transform.

This is a runnable component-level reconstruction of selected principles, not a complete or pixel-identical reconstruction of the production website. Remaining production-specific features include exact timing, content, all routes, complete asset loading, pointer-specific effects, mobile behavior and field-data integration where applicable.
