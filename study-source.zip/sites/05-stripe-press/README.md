# Stripe Press

Original website: https://press.stripe.com/

**Status:** first-pass analysis and an independent runnable component prototype. Original browser evidence: complete bounded scenario. Full production-site reconstruction: **not completed**.

- [Original references and captured structure](01-original/references.json)
- [Visual, technical and motion analysis](02-analysis/README.md)
- [Asset provenance](03-assets/README.md)
- [Standalone demo source](04-reconstruction/index.html)
- [Reusable component export](05-components/index.mjs)
- [Reproduction and verification](06-demo/README.md)

## Stack and principle

CSS perspective / pointer mapping / keyboard range. The implementation is in [the shared module](../../components/book-tilt.mjs), uses native browser APIs, and requires no runtime package installation. Import `mount(host)` to use it independently and call the returned `destroy()` before removing it or replacing the view.

## Scope

This is a CSS 3D book, not a recovered Stripe model or renderer. Cover artwork and text are original.

Observed: two canvases and Stripe-hosted bootstrap scripts. The capture shows a stacked dimensional book presentation. The production rendering library remains unverified.

The source screenshot and third-party links are research references, not reusable production assets. Original independent source code is licensed under the repository's MIT license; third-party materials retain their own rights.
