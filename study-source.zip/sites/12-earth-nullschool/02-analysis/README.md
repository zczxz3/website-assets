# Earth Nullschool: analysis

## Evidence and confidence

- Original: https://earth.nullschool.net/
- Observation: `2026-11-04T00:55:49.561610+00:00`
- Browser result: **complete bounded scenario**. Scope: initial view, PageDown and a short settlement period.
- Static subset: **completed**; parsed files: 1; parse failures: 0.
- Last retained nonempty DOM: 6 canvas element(s), 2 image element(s), 0 observed page error(s).

Observed: multiple canvases and projection/layer controls; the bounded JavaScript subset passed REA parsing. The site presents meteorological data sources and timestamps; the component uses synthetic vectors, not those live products.

The initial collector uses `captured` for successful CLI exit codes. The status above additionally checks REA completeness; an exit code of zero alone is not accepted as complete capture.

## Selected mechanism

Particles advect over an orthographic globe. Drag the view and change speed or the illustrative scientific layer.

Implementation: **Spherical projection / midpoint integration / particles**. Input is mapped to a small explicit state, which drives geometry or style updates. The component owns its event handlers and rendering resources and exposes `destroy()` for teardown. Animation frames are gated by viewport intersection and page visibility. Ambient motion respects the system preference and the gallery pause control.

## Visual design

The study brief emphasizes scientific flow. The independent demo uses an original visual system and procedural assets. The adjacent reference image records the observed production view; it is not a claim of visual equivalence. The original opening gate or loading state may hide later behaviors. Source-documented mechanisms and inferred reconstruction choices remain separate.

## Resource evidence

- `./src/main~PFYJS5Q4.js`
- `https://www.googletagmanager.com/gtag/js?id=G-6SYP36R2F0`

String fingerprints, HTML classes and a canvas count do not alone establish an active runtime dependency. See `01-original/collector-report.json` for bounded CSS measurements and code-string signals.

## Reconstruction and practical limits

The field is synthetic. It is not live weather, and the illustrative temperature layer has no measured units. Real data ingestion, temporal interpolation and scientific legends are not implemented.

Drag the globe, change flow speed and switch the illustrative layer. Reduced motion stops ambient advection. No live weather data or measured temperature scale is displayed.

This is a runnable component-level reconstruction of selected principles, not a complete or pixel-identical reconstruction of the production website. Remaining production-specific features include exact timing, content, all routes, complete asset loading, pointer-specific effects, mobile behavior and field-data integration where applicable.
