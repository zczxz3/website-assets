# Earth Nullschool

Original website: https://earth.nullschool.net/

**Status:** first-pass analysis and an independent runnable component prototype. Original browser evidence: complete bounded scenario. Full production-site reconstruction: **not completed**.

- [Original references and captured structure](01-original/references.json)
- [Visual, technical and motion analysis](02-analysis/README.md)
- [Asset provenance](03-assets/README.md)
- [Standalone demo source](04-reconstruction/index.html)
- [Reusable component export](05-components/index.mjs)
- [Reproduction and verification](06-demo/README.md)

## Stack and principle

Spherical projection / midpoint integration / particles. The implementation is in [the shared module](../../components/flow-field.mjs), uses native browser APIs, and requires no runtime package installation. Import `mount(host)` to use it independently and call the returned `destroy()` before removing it or replacing the view.

## Scope

The field is synthetic. It is not live weather, and the illustrative temperature layer has no measured units. Real data ingestion, temporal interpolation and scientific legends are not implemented.

Observed: multiple canvases and projection/layer controls; the bounded JavaScript subset passed REA parsing. The site presents meteorological data sources and timestamps; the component uses synthetic vectors, not those live products.

The source screenshot and third-party links are research references, not reusable production assets. Original independent source code is licensed under the repository's MIT license; third-party materials retain their own rights.
