# GT Flexa

Original website: https://gt-flexa.com/

**Status:** first-pass analysis and an independent runnable component prototype. Original browser evidence: complete bounded scenario. Full production-site reconstruction: **not completed**.

- [Original references and captured structure](01-original/references.json)
- [Visual, technical and motion analysis](02-analysis/README.md)
- [Asset provenance](03-assets/README.md)
- [Standalone demo source](04-reconstruction/index.html)
- [Reusable component export](05-components/index.mjs)
- [Reproduction and verification](06-demo/README.md)

## Stack and principle

Font axes / geometric fallback / editable text. The implementation is in [the shared module](../../components/variable-type.mjs), uses native browser APIs, and requires no runtime package installation. Import `mount(host)` to use it independently and call the returned `destroy()` before removing it or replacing the view.

## Scope

Commercial GT Flexa files are not bundled. Supply a licensed variable font for native axes. The width control also uses a geometric fallback, explicitly distinct from real glyph interpolation.

Primary-page documented: extensive variable-font use. The bounded application script was parsed by REA without parse failures. The commercial original font is not included.

The source screenshot and third-party links are research references, not reusable production assets. Original independent source code is licensed under the repository's MIT license; third-party materials retain their own rights.
