# GT Flexa: analysis

## Evidence and confidence

- Original: https://gt-flexa.com/
- Observation: `2026-11-04T00:55:52.234807+00:00`
- Browser result: **complete bounded scenario**. Scope: initial view, PageDown and a short settlement period.
- Static subset: **completed**; parsed files: 1; parse failures: 0.
- Last retained nonempty DOM: 0 canvas element(s), 0 image element(s), 0 observed page error(s).

Primary-page documented: extensive variable-font use. The bounded application script was parsed by REA without parse failures. The commercial original font is not included.

The initial collector uses `captured` for successful CLI exit codes. The status above additionally checks REA completeness; an exit code of zero alone is not accepted as complete capture.

## Selected mechanism

Explore width and weight as continuous controls, and edit the specimen directly.

Implementation: **Font axes / geometric fallback / editable text**. Input is mapped to a small explicit state, which drives geometry or style updates. The component owns its event handlers and rendering resources and exposes `destroy()` for teardown. Animation frames are gated by viewport intersection and page visibility. Ambient motion respects the system preference and the gallery pause control.

## Visual design

The study brief emphasizes variable type. The independent demo uses an original visual system and procedural assets. The adjacent reference image records the observed production view; it is not a claim of visual equivalence. The original opening gate or loading state may hide later behaviors. Source-documented mechanisms and inferred reconstruction choices remain separate.

## Resource evidence

- `javascripts/app.js`
- `https://www.googletagmanager.com/gtag/js?id=UA-128988891-3`
- `/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js`
- `https://static.cloudflareinsights.com/beacon.min.js/vce701823e78c4301a35b7e07294d87301792088814092`

String fingerprints, HTML classes and a canvas count do not alone establish an active runtime dependency. See `01-original/collector-report.json` for bounded CSS measurements and code-string signals.

## Reconstruction and practical limits

Commercial GT Flexa files are not bundled. Supply a licensed variable font for native axes. The width control also uses a geometric fallback, explicitly distinct from real glyph interpolation.

Change weight and width, then edit the specimen. Test a separately licensed variable font via the mount option before claiming native width-axis interpolation.

This is a runnable component-level reconstruction of selected principles, not a complete or pixel-identical reconstruction of the production website. Remaining production-specific features include exact timing, content, all routes, complete asset loading, pointer-specific effects, mobile behavior and field-data integration where applicable.
