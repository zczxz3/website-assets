# Human Terrain

Original website: https://pudding.cool/2018/10/city_3d/

**Status:** first-pass analysis and an independent runnable component prototype. Original browser evidence: complete bounded scenario. Full production-site reconstruction: **not completed**.

- [Original references and captured structure](01-original/references.json)
- [Visual, technical and motion analysis](02-analysis/README.md)
- [Asset provenance](03-assets/README.md)
- [Standalone demo source](04-reconstruction/index.html)
- [Reusable component export](05-components/index.mjs)
- [Reproduction and verification](06-demo/README.md)

## Stack and principle

Linear encoding / grid data / 3D projection. The implementation is in [the shared module](../../components/population-terrain.mjs), uses native browser APIs, and requires no runtime package installation. Import `mount(host)` to use it independently and call the returned `destroy()` before removing it or replacing the view.

## Scope

The included field is synthetic and does not estimate real population. The mount API accepts real grids. Production GHSL processing, vector tiles and Mapbox camera behavior remain separate from this small component.

Primary page documents GHSL population data and Google Earth Engine processing. Captured runtime classes include Mapbox GL canvas and controls. The entry screen and map initialization were inspected; no global population dataset is mirrored.

The source screenshot and third-party links are research references, not reusable production assets. Original independent source code is licensed under the repository's MIT license; third-party materials retain their own rights.

## Follow-up observation

Activating View Population displayed the Mapbox population terrain and year controls. This verifies the entry transition and visible terrain, not the underlying global dataset or historical accuracy.
