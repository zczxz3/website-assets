# Human Terrain: analysis

## Evidence and confidence

- Original: https://pudding.cool/2018/10/city_3d/
- Observation: `2026-11-04T00:55:34.019874+00:00`
- Browser result: **complete bounded scenario**. Scope: initial view, PageDown and a short settlement period.
- Static subset: **not-run**; parsed files: not measured; parse failures: not measured.
- Last retained nonempty DOM: 1 canvas element(s), 0 image element(s), 0 observed page error(s).

Primary page documents GHSL population data and Google Earth Engine processing. Captured runtime classes include Mapbox GL canvas and controls. The entry screen and map initialization were inspected; no global population dataset is mirrored.

The initial collector uses `captured` for successful CLI exit codes. The status above additionally checks REA completeness; an exit code of zero alone is not accepted as complete capture.

## Selected mechanism

A linear value-to-height function creates a field of columns, with continuous scenario blending and camera rotation.

Implementation: **Linear encoding / grid data / 3D projection**. Input is mapped to a small explicit state, which drives geometry or style updates. The component owns its event handlers and rendering resources and exposes `destroy()` for teardown. Animation frames are gated by viewport intersection and page visibility. Ambient motion respects the system preference and the gallery pause control.

## Visual design

The study brief emphasizes 3d data terrain. The independent demo uses an original visual system and procedural assets. The adjacent reference image records the observed production view; it is not a claim of visual equivalence. The original opening gate or loading state may hide later behaviors. Source-documented mechanisms and inferred reconstruction choices remain separate.

## Resource evidence

- `//www.earthengine.app/javascript/main.js`
- `https://api.tiles.mapbox.com/mapbox-gl-js/v0.49.0/mapbox-gl.js`
- `https://api.mapbox.com/mapbox-gl-js/v2.0.0/mapbox-gl.js`
- `https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-compare/v0.1.0/mapbox-gl-compare.js`
- `//gc.zgo.at/count.js`
- `https://pudding.cool/assets/scripts/d3.v4.12.0+jetpack.min.js`

String fingerprints, HTML classes and a canvas count do not alone establish an active runtime dependency. See `01-original/collector-report.json` for bounded CSS measurements and code-string signals.

## Reconstruction and practical limits

The included field is synthetic and does not estimate real population. The mount API accepts real grids. Production GHSL processing, vector tiles and Mapbox camera behavior remain separate from this small component.

Change the scenario blend and rotate the camera. Height uses a linear shared min/max range across both grids. The default fields are synthetic.

This is a runnable component-level reconstruction of selected principles, not a complete or pixel-identical reconstruction of the production website. Remaining production-specific features include exact timing, content, all routes, complete asset loading, pointer-specific effects, mobile behavior and field-data integration where applicable.

## Targeted follow-up

Activating View Population displayed the Mapbox population terrain and year controls. This verifies the entry transition and visible terrain, not the underlying global dataset or historical accuracy. See the follow-up Evidence in `01-original/`.
