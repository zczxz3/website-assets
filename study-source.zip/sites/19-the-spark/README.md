# 19. The Spark

Original: https://spark.thedigitalpanda.com/

Author case study: https://tympanus.net/codrops/2026/01/09/the-spark-engineering-an-immersive-story-first-web-experience/

## Evidence

Author describes scroll-controlled camera, character and tracking states within a story-first experience.

Public text entry was reviewed; live interaction capture is separately recorded. The article is author evidence, not a claim that all production behavior was exercised.

## Independent implementation

Four smooth camera keyframes frame a low-detail city with an integrated tracking overlay.

Module: `components/cinematic-city.mjs`, shared implementation: `components/batch-two.mjs`. API: `mount(host)` returns `destroy()`. Include `styles.css`.

## Limits

CPU-projected original city; no production character rigs, lighting pipeline or projected original textures.

Status: component prototype implemented; current verification is in the repository-root STUDY_VERIFICATION.md.

## Bounded original capture

Press-and-hold entry visible; full narrative not entered. HTTP: 200; browser: captured; static subset: not-run.
