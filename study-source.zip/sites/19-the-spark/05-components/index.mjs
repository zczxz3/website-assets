export {mount} from '../../../components/cinematic-city.mjs';
